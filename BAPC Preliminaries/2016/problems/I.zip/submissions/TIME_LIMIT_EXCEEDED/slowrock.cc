/*
 * Slow solution to Rock Band.
 */

#include <stdio.h>
#include <assert.h>
#include <vector>

using namespace std;


vector<int> solve(const vector<vector<int>>& prefer)
{
    int m = prefer.size();
    int s = prefer[0].size();

    vector<int> have(s + 1);
    int nsong = 0;
    int prev_nsong = 0;

    have[prefer[0][0]] = 1;
    nsong = 1;

    while (nsong > prev_nsong) {

        prev_nsong = nsong;

        for (int i = 0; i < m; i++) {
            int p = 0;
            for (int k = 0; k < s; k++) {
                if (have[prefer[i][k]]) {
                    p = k;
                }
            }
            for (int k = 0; k < p; k++) {
                if (!have[prefer[i][k]]) {
                    have[prefer[i][k]] = 1;
                    nsong++;
                }
            }
        }
    }

    vector<int> ans;
    for (int k = 1; k <= s; k++) {
        if (have[k]) {
            ans.push_back(k);
        }
    }
    return ans;
}


/* Main program. */
int main(void)
{
    // Read input.
    int m = -1, s = -1;
    scanf("%d %d", &m, &s);
    assert(m >= 1);
    assert(s >= 1);
    assert(1000000 / m >= s);
    assert(m * s <= 1000000);

    vector<vector<int>> prefer(m);
    for (int i = 0; i < m; i++) {
        for (int k = 0; k < s; k++) {
            int t = -1;
            scanf("%d", &t);
            assert(t >= 1 && t <= s);
            prefer[i].push_back(t);
        }
    }

    // Solve problem.
    vector<int> order = solve(prefer);

    // Write output.
    printf("%zu\n", order.size());
    bool first = true;
    for (int k : order) {
        printf("%s%d", (first ? "" : " "), k);
        first = false;
    }
    printf("\n");

    return 0;
}

// end
