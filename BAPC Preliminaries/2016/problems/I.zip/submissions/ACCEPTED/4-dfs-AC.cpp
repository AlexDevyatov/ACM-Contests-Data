// This solution is very similar to 1-bfs-cluttered-AC.cpp, except that it uses
// a depth-first search instead of a breadth-first search. This may cause a
// runtime error due to stack overflow (as it does on my machine), but it may
// be fine in an environment with larger stack size.
//
// If you are running DOMjudge from the live-image provided on domjudge.org,
// this solution should be ACCEPTED, since the stack size on this system is
// larger than normal. In any other environment, it may well be a RUNTIME ERROR.
// 
// This program is a variation on 3-dfs-AC.cpp. We reduce the memory footprint
// of the recursive DFS by eliminating as many variables as possible. This does
// give a stack overflow on typical linux systems when compiled normally (with
// no optimisation or -O2), but works fine when compiled with -O3. The optimiser
// probably manages to apply tail recursion.
// 
// In the contest we only use -O2, so the success of this solution still
// depends on the stack size. However, this solution is way more complicated
// than needed, so it's not likely to be an actual problem for teams submitting
// similar solutions.
// 
// 
// Main idea for this solution:
// 
//     Create a graph where every song has a vertex. The preference list for
//     every single band member becomes a path in the graph (directed from right
//     to left). Now if song X is on the minimal set list, then all songs 
//     reachable from X should also be on the set list. Hence we do a dfs
//     starting from every song that occurs as a favourite song for one of the
//     band members. The minimum set list consists of all songs that can are
//     reached by the dfs.
//
// Total runtime: O(M * S).

#include <iostream>
#include <vector>
#include <cstring>

using namespace std;

const int MAX_S = 1000000;

bool visited[MAX_S];
vector<int> neighbours[MAX_S];

void dfs(int cur) {
	if (visited[cur]) return;
	visited[cur] = true;
	for (unsigned i = 0; i < neighbours[cur].size(); i++) {
		dfs(neighbours[cur][i]);
	}
}

int main() {
	// Read input and convert it to a graph.
	int M, S;
	cin >> M >> S;
	vector<int> startingPoints;
	for (int i = 0; i < M; i++) {
		int prev = -1;
		for (int j = 0; j < S; j++) {
			int cur;
			cin >> cur;
			cur--;
			if (j > 0) {
				// Add edge from cur to prev.
				neighbours[cur].push_back(prev);
			}
			else {
				// Add cur to the list of starting points.
				startingPoints.push_back(cur);
			}
			prev = cur;
		}
	}
	
	// Depth-first search.
	memset(visited, 0, sizeof visited);
	for (int i = 0; i < M; i++) {
		dfs(startingPoints[i]);
	}
	
	// Make a list of visited veritces.
	vector<int> setlist;
	for (int j = 0; j < S; j++) {
		if (visited[j]) {
			setlist.push_back(j + 1);
		}
	}
	
	// Write output.
	cout << setlist.size() << endl;
	for (vector<int>::iterator it = setlist.begin(); it != setlist.end(); it++) {
		cout << (it == setlist.begin() ? "" : " ") << *it;
	}
	cout << endl;
	return 0;
}
