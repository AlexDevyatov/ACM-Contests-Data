// Java port of the model solution 2-greedy-AC.cpp.

import java.io.*;
import java.util.*;
import java.lang.*;

public class RockbandFast {
	static BufferedReader reader;
	static StringTokenizer tokenizer;
	
	static String next() throws IOException {
		while (!tokenizer.hasMoreTokens()) {
			tokenizer = new StringTokenizer(reader.readLine());
		}
		return tokenizer.nextToken();
	}
	
	static int nextInt() throws IOException {
		return Integer.parseInt(next());
	}
	
	public static void main(String[] args) throws Exception {
		reader = new BufferedReader(new InputStreamReader(System.in));
		tokenizer = new StringTokenizer("");
		int M = nextInt();
		int S = nextInt();
		int[][] preferenceList = new int[M][S];
		int[] worstRankingForSong = new int[S];
		for (int i = 0; i < M; i++) {
			for (int j = 0; j < S; j++) {
				int cur = nextInt() - 1;
				preferenceList[i][j] = cur;
				worstRankingForSong[cur] = Math.max(worstRankingForSong[cur], j + 1);
			}
		}
		
		int minimumSetListLength = 1;
		for (int j = 0; j < minimumSetListLength; j++) {
			for (int i = 0; i < M; i++) {
				minimumSetListLength = Math.max(minimumSetListLength, worstRankingForSong[preferenceList[i][j]]);
			}
		}
		
		boolean first = true;
		System.out.println(minimumSetListLength);
		StringBuilder setList = new StringBuilder();
		for (int j = 0; j < S; j++) {
			if (worstRankingForSong[j] <= minimumSetListLength) {
				if (!first) setList.append(' ');
				first = false;
				setList.append(j + 1);
			}
		}
		System.out.println(setList);
	}
}
