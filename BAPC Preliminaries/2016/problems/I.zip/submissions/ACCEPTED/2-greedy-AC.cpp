// This is the model solution.
// 
// This greedy solution is linear in the input size. We only need two passes over
// the input.
//     
//   * In the first pass, we read the input and compute the lowest (i.e. worst)
//     ranking for every song.
//     
//   * In the second pass, we process the input column by column. We keep track
//     of the minimum number of songs we are forced to include on the set list.
//     This is done greedily: if we are forced to include song X, and one of the
//     band members ranks this as the Yth song on his list, then we know that we
//     have to include at least Y songs on the minimal set list.
// 
// Total runtime: O(M * S).

#include <iostream>
#include <vector>

using namespace std;

int main() {
	int M, S;
	cin >> M >> S;
	vector<vector<int> > v(M);
	vector<int> lowestRankingForSong(S, 0);
	
	// First pass: read input row by row, compute the lowest ranking for each song.
	for (int i = 0; i < M; i++) {
		for (int j = 0; j < S; j++) {
			int cur;
			cin >> cur;
			cur--;
			v[i].push_back(cur);
			lowestRankingForSong[cur] = max(lowestRankingForSong[cur], j + 1);
		}
	}
	
	// Second pass: process input column by column. For every song we find, we have
	//              to increase the minimum setlist length so that it includes all
	//              occurrences of that particular song.
	int minimumSetlistLength = 1;
	for (int j = 0; j < minimumSetlistLength; j++) {
		for (int i = 0; i < M; i++) {
			minimumSetlistLength = max(minimumSetlistLength, lowestRankingForSong[v[i][j]]);
		}
	}
	
	// Ouput answer.
	bool first = true;
	cout << minimumSetlistLength << endl;
	for (int j = 0; j < S; j++) {
		if (lowestRankingForSong[j] <= minimumSetlistLength) {
			cout << (first ? "" : " ") << j + 1;
			first = false;
		}
	}
	cout << endl;
	return 0;
}
