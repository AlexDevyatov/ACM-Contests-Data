#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct interval_t {
	int a, b, n;
	interval_t() {}
	interval_t(int _a, int _b, int _n) : a(_a), b(_b), n(_n) {}
	bool operator<(const interval_t& other) const {
		if (a != other.a) return a < other.a;
		return b < other.b;
	}
};

int main() {
	int M, S;
	cin >> M >> S;
	int l[M][S];
	vector<int> bestRanking(S, S);
	vector<int> worstRanking(S, 0);
	for (int i = 0; i < M; i++) {
		for (int j = 0; j < S; j++) {
			cin >> l[i][j];
			int cur = l[i][j] - 1;
			worstRanking[cur] = max(worstRanking[cur], j);
			bestRanking[cur] = min(bestRanking[cur], j);
		}
	}
	vector<interval_t> intervals;
	for (int j = 0; j < S; j++) {
		intervals.push_back(interval_t(bestRanking[j], worstRanking[j], j + 1));
	}
	sort(intervals.begin(), intervals.end());
	int B = 0;
	vector<int> songsSeen;
	for (int j = 0; j < S; j++) {
		if (intervals[j].a > B) break;
		B = max(B, intervals[j].b);
		songsSeen.push_back(intervals[j].n);
	}
	sort(songsSeen.begin(), songsSeen.end());
	cout << songsSeen.size() << endl;
	for (vector<int>::iterator it = songsSeen.begin(); it != songsSeen.end(); it++) {
		cout << (it == songsSeen.begin() ? "" : " ") << *it;
	}
	cout << endl;
	return 0;
}
