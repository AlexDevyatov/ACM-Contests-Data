// First solution I came up with, even before the problem text was written down.
// In retrospect this solution is more complicated than necessary.
// 
// 
// Main idea for this solution:
// 
//     Create a graph where every song has a vertex. The preference list for
//     every single band member becomes a path in the graph (directed from right
//     to left). Now if song X is on the minimal set list, then all songs
//     reachable from X should also be on the set list. Hence we do a bfs
//     starting from all songs that occur as a favourite song for one of the
//     band members. The minimum set list consists of all songs that can are
//     reached by the bfs.
//
// Total runtime: O(M * S).

#include <iostream>
#include <cassert>
#include <vector>
#include <cstring>
#include <queue>

using namespace std;

const int MAX_CASES = 100;
const long long MAX_MS = 1000000;

vector<int> neighbours[MAX_MS];
int numVisited;
bool visited[MAX_MS];
queue<int> q;

void schedule(int x) {
	if (!visited[x]) {
		#ifdef DEBUG
			cerr << "  pushed " << x + 1 << "." << endl;
		#endif
		visited[x] = true;
		q.push(x);
		numVisited++;
	}
}

int main() {
	long long M, S;
	cin >> M >> S;
	assert(M >= 1 && M <= MAX_MS);
	assert(S >= 1 && S <= MAX_MS);
	assert(M * S <= MAX_MS);
	
	// Initialise the bfs queue.
	numVisited = 0;
	memset(visited, 0, sizeof visited);
	
	// Read the rest of the input and convert it to a graph.
	for (int i = 0; i < M; i++) {
		int prev = -1;
		for (int j = 0; j < S; j++) {
			int cur;
			cin >> cur;
			assert(cur >= 1 && cur <= S);
			cur--;
			if (j > 0) {
				// Add edge from cur to prev.
				neighbours[cur].push_back(prev);
			}
			else {
				// Push cur to the bfs queue.
				schedule(cur);
			}
			prev = cur;
		}
	}
	
	// Breadth-first search.
	while (!q.empty()) {
		int cur = q.front();
		q.pop();
		for (vector<int>::iterator it = neighbours[cur].begin(); it != neighbours[cur].end(); it++) {
			schedule(*it);
		}
	}
	
	// Output answer.
	cout << numVisited << endl;
	bool printSpace = false;
	for (int j = 0; j < S; j++) {
		if (visited[j]) {
			cout << (printSpace ? " " : "") << j + 1;
			printSpace = true;
		}
	}
	cout << '\n';
	return 0;
}
