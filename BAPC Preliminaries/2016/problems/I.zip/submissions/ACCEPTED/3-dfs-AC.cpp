// This solution is very similar to 1-bfs-cluttered-AC.cpp, except that it uses
// a depth-first search instead of a breadth-first search. This may cause a
// runtime error due to stack overflow (as it does on my machine), but it may
// be fine in an environment with larger stack size.
// 
// If you are running DOMjudge from the live-image provided on domjudge.org,
// this solution should be ACCEPTED, since the stack size on this system is
// larger than normal. In any other environment, it may well be a RUNTIME ERROR.
//
// Interestingly, the DFS can be made to work (on normal computers); see also
// 4-dfs-AC.cpp. That program will result in a stack overflow on typical linux
// systems if it is compiled without optimisation (or up to -O2), but the
// problem disappears with -O3. The optimiser probably manages to apply tail
// recursion. This trick does not work with this version of the program
// (3-dfs-AC.cpp); even the -O3 setting cannot prevent stack overflow.
// 
// 
// Main idea for this solution:
// 
//     Create a graph where every song has a vertex. The preference list for
//     every single band member becomes a path in the graph (directed from right
//     to left). Now if song X is on the minimal set list, then all songs 
//     reachable from X should also be on the set list. Hence we do a dfs
//     starting from every song that occurs as a favourite song for one of the
//     band members. The minimum set list consists of all songs that can are
//     reached by the dfs.
//
// Total runtime: O(M * S).

#include <iostream>
#include <vector>
#include <cstring>

using namespace std;

const int MAX_S = 1000000;

bool visited[MAX_S];
vector<int> neighbours[MAX_S];

int dfs(int cur) {
	if (visited[cur]) return 0;
	visited[cur] = true;
	int numVisited = 1;
	for (vector<int>::iterator it = neighbours[cur].begin(); it != neighbours[cur].end(); it++) {
		numVisited += dfs(*it);
	}
	return numVisited;
}

int main() {
	// Read input and convert it to a graph.
	int M, S;
	cin >> M >> S;
	vector<int> startingPoints;
	for (int i = 0; i < M; i++) {
		int prev = -1;
		for (int j = 0; j < S; j++) {
			int cur;
			cin >> cur;
			cur--;
			if (j > 0) {
				// Add edge from cur to prev.
				neighbours[cur].push_back(prev);
			}
			else {
				// Add cur to the list of starting points.
				startingPoints.push_back(cur);
			}
			prev = cur;
		}
	}
	
	// Depth-first search.
	int numVisited = 0;
	memset(visited, 0, sizeof visited);
	for (int i = 0; i < M; i++) {
		numVisited += dfs(startingPoints[i]);
	}
	
	// Output answer.
	cout << numVisited << endl;
	bool first = true;
	for (int j = 0; j < S; j++) {
		if (visited[j]) {
			cout << (first ? "" : " ") << j + 1;
			first = false;
		}
	}
	cout << endl;
	return 0;
}
