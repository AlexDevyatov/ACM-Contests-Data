 /*
    Java Solution for Rockband
    A problem for BAPC 2016
    author: Peter Kluit
    July 2016
  */

import java.util.*;
import java.io.*;
public class Rockband{
   public static void main(String []args){
      run();
   }

   public static void run(){
 
      try{
         BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
         String line = input.readLine();
         Scanner st = new Scanner(line);
         int m = st.nextInt();
         int s = st.nextInt();
         int [][] likes = new int[m][s];
         for (int l = 0; l < m; l++){
            line = input.readLine();
            String[] split_line = line.split(" ");
            for (int ss = 0; ss < s; ss++)
               likes[l][ss] = Integer.parseInt(split_line[ss]);
         }
         Rockband solver = new Rockband(likes);
         System.out.println(solver.solve());
         System.out.println(solver.getChoice());

         input.close();
      }
      catch (IOException iox){}
   }
////////////////////////////////////////////

   int [][] order;
   TreeSet<Integer> chosen = new TreeSet<Integer>();
   public Rockband (int [][] likes){
      order = likes;
   }

   public int solve(){
      for (int s = 0; s < order[0].length; s++){
         for (int m = 0; m < order.length; m++)
            chosen.add(order[m][s]);
         if (chosen.size() == s + 1)
            return s+1;
      }
      return order[0].length;
   }

   public String getChoice(){
      StringBuilder result = new StringBuilder(chosen.size());
      for (int n : chosen)
         result.append(n + " ");
      String preAnswer = result.toString();
      return preAnswer.trim();
   }
}
