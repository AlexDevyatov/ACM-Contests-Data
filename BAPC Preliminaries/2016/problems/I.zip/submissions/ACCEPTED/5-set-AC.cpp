// C++ port of Peter's solution (Rockband.java).

#include <iostream>
#include <set>

using namespace std;

int main() {
	int M, S;
	cin >> M >> S;
	int v[M][S];
	for (int i = 0; i < M; i++) {
		for (int j = 0; j < S; j++) {
			int cur;
			cin >> cur;
			v[i][j] = cur;
		}
	}
	set<int> setList;
	for (int j = 0; j < S; j++) {
		for (int i = 0; i < M; i++) {
			setList.insert(v[i][j]);
		}
		if ((int) setList.size() == j + 1) break;
	}
	cout << setList.size() << endl;
	for (auto it : setList) {
		cout << (it == *setList.begin() ? "" : " ") << it;
	}
	cout << endl;
	return 0;
}
