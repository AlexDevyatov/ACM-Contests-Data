#include <iostream> // strings/streams
#include <cstdio> // utils
#include <string>
#include <cstring>
#include <sstream>
#include <vector> // datastructures
#include <algorithm>

using namespace std;

// O(n^2 + k) solution.

int main()
{
	int n;
	cin >> n;
	int k;
	cin >> k;
	
	int obvious_matches = 0;
	int matched_already = 0;
	int unknown_cards = 0;
	int single_cards = 0;
	vector<string> cards(n+1, "");
	
	for(int i = 0; i < k; i++)
	{
		int c1, c2;
		string s1, s2;
		cin >> c1 >> c2 >> s1 >> s2;
		if(s1 == s2)
			matched_already++;
		cards[c1] = s1;
		cards[c2] = s2;
	}
	for(int i = 1; i <= n; i++)
	{
		bool found_match = false;
		if(cards[i] == "")
		{
			unknown_cards++;
			continue;
		}
		for(int j = i + 1; j <= n; j++)
		{
			if(cards[i] == cards[j])
			{
				obvious_matches++;				
				found_match = true;
			}
		}
		if(!found_match)
			single_cards++;
	}
	
	single_cards -= obvious_matches; // We counted every obvious match as a single card as well, as we only searched further down the list.
	
	cout << obvious_matches - matched_already + (single_cards == unknown_cards ? single_cards : 0) + ((single_cards == 0 && unknown_cards == 2) ? 1 : 0) << "\n";
	
	return 0;
}