// This compare script has a pedantic mode for testing purposes only. During the
// contest it should be set to flexible mode, just like the rest of DOMjudge.
// This is how the script was delivered to you.
// 
// By manually configuring this script to work in pedantic mode, you are putting
// the teams competing at your own university at an unfair disadvantage.

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

const int MIN_LANGUAGES = 2;
const int MAX_LANGUAGES = 100;
const int MIN_TRANSLATORS = 1;
const int MAX_TRANSLATORS = 200;

ifstream inputfile;
ofstream commentsfile;

typedef pair<int,int> translator_t;

ostream& operator<<(ostream& os, const translator_t& t) {
	os << '{' << t.first << ',' << t.second << '}';
	return os;
}

void protectedGetline(string& s) {
	if (!getline(inputfile, s)) {
		cerr << "Error: input file ended unexpectedly." << endl;
		commentsfile << "Error: input file ended unexpectedly." << endl;
		exit(1);
	}
}

void removeSpaceAndConvertToLowerCase(string& s) {
	string t;
	unsigned l = s.size();
	for (unsigned i = 0; i < l; i++) {
		if (isspace(s[i])) continue;
		t.push_back(tolower(s[i]));
	}
	s = t;
}

void stripSuperfluousWhitespace(string& s) {
	vector<string> v;
	s.push_back(' ');
	unsigned l = s.size();
	string cur;
	for (unsigned i = 0; i < l; i++) {
		if (isspace(s[i])) {
			if (!cur.empty()) {
				v.push_back(cur);
			}
			cur = "";
		}
		else {
			cur.push_back(s[i]);
		}
	}
	s = "";
	for (vector<string>::iterator it = v.begin(); it != v.end(); it++) {
		if (it != v.begin()) s.push_back(' ');
		for (string::iterator jt = it->begin(); jt != it->end(); jt++) {
			s.push_back(*jt);
		}
	}
}

int WRONG_ANSWER() {
	commentsfile << endl;
	commentsfile << "Verdict for this test case: WRONG ANSWER" << endl;
	return 43;
}

int ACCEPTED() {
	commentsfile << endl;
	commentsfile << "Verdict for this test case: OK" << endl;
	return 42;
}

int main(int argc, char* argv[]) {
	// Check for missing arguments.
	if (argc < 4) {
		cerr << "Error in invocation of " << argv[0] << ": missing argument";
		if (argc < 3) cerr << 's';
		cerr << "." << endl;
		cout << "Internal error." << endl;
		return 1;
	}
	
	// Open the input file.
	inputfile.open(argv[1]);
	if (inputfile.fail()) {
		cerr << "Error in " << argv[0] << ": failed to open input file (\"" << argv[1] << "\")." << endl;
		cout << "Internal error." << endl;
		return 1;
	}
	
	// We will ignore the jury output file (provided in argv[2]), for we don't need it.
	
	// Open the comments file.
	string s(argv[3]);
	if (s.empty() || s[s.size() - 1] != '/') s.push_back('/');
	s.append("judgemessage.txt");
	commentsfile.open(s.c_str());
	if (commentsfile.fail()) {
		cerr << "Error in " << argv[0] << ": failed to open comments file (\"" << s << "\")." << endl;
		cout << "Internal error." << endl;
		return 1;
	}
	
	// Produce a warning if there are too many arguments.
	if (argc > 4) {
		commentsfile << "Warning: ignoring additional arguments (";
		for (int i = 4; i < argc; i++) {
			if (i > 4) cerr << ", ";
			commentsfile << '"' << argv[i] << '"';
		}
		commentsfile << ")." << endl;
	}
	
	// ---------------------------------------------------------------------
	// Actual verification starts HERE.
	// ---------------------------------------------------------------------
	
	#ifdef PEDANTIC
		commentsfile << "This is the output validator for problem \"Translators' Dinner\", working in pedantic mode." << endl;
	#else
		commentsfile << "This is the output validator for problem \"Translators' Dinner\", working in flexible mode." << endl;
	#endif
	
	// First read the input file.
	int N, M;
	protectedGetline(s);
	sscanf(s.c_str(), "%d %d", &N, &M);
	char reconstruction[100];
	sprintf(reconstruction, "%d %d", N, M);
	if (string(reconstruction) != s) {
		commentsfile << "Input warning: malformed data  \"" << s << "\" on first line of input. This might cause team solutions to crash." << endl;
	}
	vector<translator_t> translators;
	for (int i = 0; i < M; i++) {
		protectedGetline(s);
		int A, B;
		sscanf(s.c_str(), "%d %d", &A, &B);
		sprintf(reconstruction, "%d %d", A, B);
		if (string(reconstruction) != s) {
			commentsfile << "Input warning: malformed edge \"" << s << "\" detected. This might cause team solutions to crash." << endl;
		}
		if (A < 0 || A >= N || B < 0 || B >= N || A == B) {
			commentsfile << "Input warning: illegal edge (" << A << "," << B << ") detected. I will ignore this edge..." << endl;
			continue;
		}
		translators.push_back(translator_t(A, B));
	}
	if (getline(inputfile, s)) {
		commentsfile << "Input warning: found additional data after last edge. This data will be ignored..." << endl;
	}
	bool impossible = (M % 2 != 0);
	int expectedOutputSize = (impossible ? 1 : M / 2);
	
	// Now read all team output.
	vector<string> teamOutput;
	while (getline(cin, s)) {
		#ifndef PEDANTIC
			if (s.empty()) continue;
		#endif
		teamOutput.push_back(s);
		#ifdef PEDANTIC
			if (cin.fail() || cin.eof()) {
				commentsfile << "Problem with team output: missing final newline." << endl;
				commentsfile << "                          (Turn off pedantic mode to suppress this kind of verdict.)" << endl;
				return WRONG_ANSWER();
			}
		#endif
	}
	
	// Check team output in the impossible case.
	if (impossible) {
		#ifndef PEDANTIC
			if (!teamOutput.empty()) {
				removeSpaceAndConvertToLowerCase(teamOutput[0]);
			}
		#endif
		if (teamOutput.size() == 1 && teamOutput[0] == "impossible") {
			commentsfile << "The team correctly determined that no matching can be made. Well done!" << endl;
			return ACCEPTED();
		}
		else {
			commentsfile << "Problem with team output: team failed to recognise impossible test case." << endl;
			if (teamOutput.size() == 1) {
				commentsfile << "(There is only one line of output, so this may be a spelling error.)" << endl;
			}
			return WRONG_ANSWER(); 
		}
	}
	
	if ((int) teamOutput.size() != expectedOutputSize) {
		if (!teamOutput.empty()) {
			removeSpaceAndConvertToLowerCase(teamOutput[0]);
		}
		if (teamOutput.size() == 1 && teamOutput[0] == "impossible") {
			commentsfile << "Problem with team output: team incorrectly concluded that the test case is impossible." << endl;
			commentsfile << "                          (A matching does indeed exist.)" << endl;
		}
		else {
			commentsfile << "Problem with team output: wrong number of lines (" << teamOutput.size() << " detected, should be " << expectedOutputSize << ")." << endl;
			commentsfile << "                          (I will make no further attempts at parsing the team output.)" << endl;
		}
		return WRONG_ANSWER();
	}
	
	// ---------------------------------------------------------------------
	// We will henceforth assume that a matching exists.
	// 
	// Now all we have to do is check that the team output represents a
	// valid matching.
	// ---------------------------------------------------------------------
	vector<int> numMatches(M, 0);
	int numProblems = 0;
	for (int curmatch = 0; curmatch < expectedOutputSize; curmatch++) {
		s = teamOutput[curmatch];
		#ifndef PEDANTIC
			stripSuperfluousWhitespace(s);
		#endif
		int A, B;
		sscanf(s.c_str(), "%d %d", &A, &B);
		sprintf(reconstruction, "%d %d", A, B);
		if (string(reconstruction) != s) {
			commentsfile << "Problem with team output: unable to parse line " << curmatch + 1 << ": \"" << teamOutput[curmatch] << "\"." << endl;
			numProblems++;
			continue;
		}
		if (A < 0 || A >= M || B < 0 || B >= M || A == B) {
			commentsfile << "Problem with team output: illegal translator pair (" << A << "," << B << ") detected." << endl;
			numProblems++;
			continue;
		}
		if (  translators[A].first != translators[B].first  && translators[A].first != translators[B].second
		   && translators[A].second != translators[B].first && translators[A].second != translators[B].second) {
			commentsfile << "Problem with team output: no common language between translators " << translators[A] << " and " << translators[B] << "." << endl;
			numProblems++;
		}
		if (numMatches[A] != 0) {
			commentsfile << "Problem with team output: translator " << A << " is matched more than once." << endl;
			numProblems++;
		}
		numMatches[A]++;
		if (numMatches[B] != 0) {
			commentsfile << "Problem with team output: translator " << B << " is matched more than once" << endl;
			numProblems++;
		}
		numMatches[B]++;
	}
	vector<int> unmatched;
	for (int i = 0; i < M; i++) {
		if (numMatches[i] == 0) unmatched.push_back(i);
	}
	if (!unmatched.empty()) {
		commentsfile << "The following translators remain unmatched:";
		for (vector<int>::iterator it = unmatched.begin(); it != unmatched.end(); it++) {
			commentsfile << ' ' << *it;
		}
		commentsfile << "." << endl;
		numProblems++;
	}
	
	// ---------------------------------------------------------------------
	// Print concluding remarks.
	// ---------------------------------------------------------------------
	if (numProblems == 0) {
		commentsfile << "The team provided a valid matching. Well done!" << endl;
		return ACCEPTED();
	}
	else {
		commentsfile << endl;
		commentsfile << "Summary: there were " << numProblems << " problems." << endl;
		return WRONG_ANSWER();
	}
}
