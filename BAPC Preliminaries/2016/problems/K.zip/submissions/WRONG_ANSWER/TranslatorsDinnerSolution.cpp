#include <iostream>

using namespace std;

int main() {
  int T;
  cin >> T;
  while(T--) {
    // Read and discard the input.
    int n,m;
    cin >> n >> m;
    string dummy;
    for(int i = 0; i < n + 2*m; i++) {
      cin >> dummy;
    }
    
    if(m & 1)
      cout << "impossible" << endl;
    else
      cout << "possible" << endl;
  }
}
