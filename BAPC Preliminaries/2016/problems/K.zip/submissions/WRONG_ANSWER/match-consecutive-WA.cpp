// Simply match consecutive numbers: 0 and 1, 2 and 3, 4 and 5, et cetera.
// 
// Of course the probability of accidentally producing a valid matching is
// very small, since the matched translators are likely not to have a language
// in common.

#include <iostream>

using namespace std;

int main() {
	int N, M;
	cin >> N >> M;
	if (M % 2) {
		cout << "impossible" << endl;
	}
	else {
		for (int i = 0; i < M; i += 2) {
			cout << i << ' ' << i + 1 << endl;
		}
	}
	return 0;
}
