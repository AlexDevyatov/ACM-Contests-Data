// Output floor(M / 2) random pairs of compatible translators.
// 
// Obviously this solution is very likely to output certain translators more
// than once, while at the same time leaving out others entirely.

#include <iostream>
#include <cstdlib>
#include <vector>

using namespace std;

typedef pair<int,int> translator_t;

vector<translator_t> translators;

bool unmatchable(int x, int y) {
	if (x == y) return true;
	translator_t X = translators[x];
	translator_t Y = translators[y];
	return X.first != Y.first && X.first != Y.second && X.second != Y.first && X.second != Y.second;
}

int main() {
	srand(42);
	int N, M;
	cin >> N >> M;
	for (int i = 0; i < M; i++) {
		int A, B;
		cin >> A >> B;
		translators.push_back(translator_t(A, B));
	}
	int half = M / 2;
	for (int i = 0; i < half; i++) {
		int x = rand() % M;
		int y = x;
		while (unmatchable(x, y)) {
			y = rand() % M;
		}
		cout << x << ' ' << y << endl;
	}
	return 0;
}
