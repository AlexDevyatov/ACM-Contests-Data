/*
   Solution in Java for Translators Dinner
   a problem for BAPC2016
   author: Peter Kluit
   September 2016
   backtracking; should be too slow
 */

import java.util.*;
public class DinnerSlow{
   public static void main (String [] args){
      run();
   }
   
   private static void run(){
      Scanner ir = new Scanner(System.in);
      int talen = ir.nextInt();
      int tolken = ir.nextInt();

      if (tolken % 2 == 1)
         System.out.println("impossible");
      else{
         DinnerSlow dinner = new DinnerSlow(tolken);
         for (int k = 0; k < tolken; k++){
             int t1 = ir.nextInt();
             int t2 = ir.nextInt();
             dinner.addTolk(k, t1, t2);
         }
         dinner.printSolution();
      }

   }
//////////////////////////////
   int [][] tolk;
   int tolken;
   //ArrayList<int []> tables;

   public DinnerSlow(int tolken){
     
      this.tolken = tolken;
      tolk = new int[tolken][2];
   }

   public void addTolk(int k, int t1, int t2){
      tolk[k][0] = t1;
      tolk[k][1] = t2;
   }

   public void printSolution(){
       //tables = new ArrayList<int []>();
       if (!extend(0))
          System.out.println("--impossible");
   }
   
   private boolean extend(int t){
      if (t == tolken)
         return true;
      if (tolk[t] == null)
         return extend(t + 1);
      for (int t2 = t + 1; t2 < tolken ; t2++)
           if (tolk[t2] != null){
              if (match(tolk[t], tolk[t2])){
                 int [] keep = tolk[t2];
                 tolk[t2] = null;
                 if (extend(t + 1)){
                    System.out.println(t + " " + t2);
                    return true;
                 }
                 else{
                    tolk[t2] = keep;
                 }
              }
            }
       return false;
   }

   private boolean match(int [] t1, int [] t2){
       return t1[0] == t2[0] ||
              t1[0] == t2[1] ||
              t1[1] == t2[0] ||
              t1[1] == t2[1] ;
   }
}
