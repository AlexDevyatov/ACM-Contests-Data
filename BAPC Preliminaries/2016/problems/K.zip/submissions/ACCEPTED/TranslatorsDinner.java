/*
   Solution in Java for Translators Dinner
   a problem for BAPC2016
   author: Peter Kluit
   September 2016
 */

import java.util.*;
public class TranslatorsDinner{

   public static void main (String [] args){
      run();
   }

   private static void run(){
      Scanner ir = new Scanner(System.in);
      int talen = ir.nextInt();
      int tolken = ir.nextInt();
      if (tolken % 2 == 1)
         System.out.println("impossible");
      else{
         TranslatorsDinner dinner = new TranslatorsDinner(talen);
         for (int k = 0; k < tolken; k++){
             int t1 = ir.nextInt();
             int t2 = ir.nextInt();
             dinner.addTolk(k, t1, t2);
         }
         dinner.printSolution();
      }
   }

//////////////////////////////
   TaalLijst [] tabel;
   Taal [] taal;
   int talen;
   Hashtable<Long,Integer> tolken = new Hashtable<Long,Integer>();

   public TranslatorsDinner(int talen){
      this.talen = talen;
      taal = new Taal[talen + 1];
      for (int t = 0; t <= talen; t++)
         taal[t] = new Taal(t);
   }

   public void addTolk(int k, int t1, int t2){
       taal[t1].addBuur(taal[t2]);
       taal[t2].addBuur(taal[t1]);
       putTolk(k, t1, t2);
   }
   
   private void putTolk (int k, int t1, int t2){
      long key = code(t1, t2);
      tolken.put(key, k);
   }

   private int popTolk(Taal t1, Taal t2){
      long key = code(t1, t2);
      return tolken.get(key);
   }

   private long code(Taal t1, Taal t2){
       int tt1 = t1.name;
       int tt2 = t2.name;
       return code(tt1, tt2);
   }

   private long code(int  t1, int t2){
       return 2L * (talen + 1) * t1 * t2 + t1 + t2;
   }

   public void printSolution(){
      tabel = new TaalLijst[talen + 1];
      tabel[0] = new TaalLijst();
      tabel[0].add(taal[0]);
      taal[0].dist = 0;
      int d = 0;

      while (tabel[d] != null){
         for (Taal t : tabel[d]){
            for (Taal t2 : t.buren)
               if (t2.dist > d + 1){
                   t2.dist = d + 1;
                   if (tabel[d+1] == null)
                      tabel[d+1] = new TaalLijst();
                   tabel[d+1].add(t2);
               }
         }
         d++;
      }
      // tabel[d] == null

      for (d-- ; d >= 0; d--){
         for (Taal t : tabel[d]){
            Collections.sort(t.buren);
            while (t.buren.size() > 1){
               int l = t.buren.size();
               Taal t1 = t.buren.get(l-1);
               Taal t2 = t.buren.get(l-2);
               t.dropBuur(t1);
               t.dropBuur(t2);
               t1.dropBuur(t);
               t2.dropBuur(t);
               int tolk1 = popTolk(t, t1);
               int tolk2 = popTolk(t, t2);
               System.out.println(tolk1 + " " + tolk2);
            }
         }
      }
   }

   private void dumpTabel(int d){
      System.out.println("Op afstand " + d );
      tabel[d].dump();
   }
}

class TaalLijst extends ArrayList<Taal> {
   public void dump(){
      for (Taal  t : this) 
        System.out.println("  "  + t);
   }

}

class Taal implements Comparable<Taal>{
   TaalLijst buren = new TaalLijst();
   int name;
   int dist = Integer.MAX_VALUE;

   public Taal(int no){
      name = no;
   }
   
   public void addBuur(Taal t){
      buren.add(t);
   }
   
   public void dropBuur(int t){
      buren.remove(t);
   }

   public void dropBuur(Taal t){
      buren.remove(t);
   }
   
   public int compareTo(Taal that){
       return this.dist - that.dist;
   }

   public String toString(){
      return "taal " + name + " at dist " + dist;
   }

   public void dump(){
       System.out.println(this);
       buren.dump();
   }

}