// Same as the other solution, except with some extra whitespace.
// This is to check just how flexible the output validator is.

#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <queue>

using namespace std;

class Graph {
  public:
    vector<int> nodes;
    map<int, vector<pair<int,int>>> adj;
};

// Takes a connected simple Graph with an even number of edges and prints
// an edge matching to stdout.
void edge_match(Graph g) {
  // If there are no edges in the graph, we are done.
  if(g.nodes.size() == 1)
    return;

  // Just to be sure, although technically not necessary.
  sort(g.nodes.begin(), g.nodes.end());

  // The idea works as follows: we pick a language (the "break node") and
  // investigate what happens when we decide that no pair of translators
  // will be matched up on that language. If that gives problems, then we
  // know we have to match there; otherwise, we have produced a simpler
  // graph.

  int break_node;
  for(int n : g.nodes) {
    if (g.adj[n].size() > 1) {
      break_node = n;
      break;
    }
  }

  // Now, we suppose that we remove the break node. We collect the connected
  // components that would result by removing it. (Or, really: by replacing
  // it with a bunch of degree 1 nodes.)

  int con_comp = 0; // The number of components.
  vector<int> edge_ct; // The number of edges in each component.
  map<int, int> comp; // The component of a given node.
  queue<int> q; // A queue to use for a BFS.

  // We go through the neighbours of the break node, and start DFSs there.
  for(auto p : g.adj[break_node]) {
    int n = p.first;
    if(comp.find(n) == comp.end()) {
      comp[n] = con_comp;
      edge_ct.push_back(g.adj[n].size() + 1);
      q.push(n);
      while(!q.empty()) {
        int k = q.front(); q.pop();
        for(auto r : g.adj[k]) {
          int l = r.first;
          if(comp.find(l) == comp.end() && l != break_node) {
            comp[l] = con_comp;
            edge_ct[con_comp] += g.adj[l].size();
            q.push(l);
          }
        }
      }
      con_comp++;
    }
    else {
      edge_ct[comp[n]]++;
    }
  }
  
  // We have double counted edges, so to find the number of edges in a
  // component we divide by 2.
  for(int i = 0; i < con_comp; i++) {
    edge_ct[i] /= 2;
  }

  // Now we run through the connected components. If one has an even number
  // of edges, we can recursively call this function. If two have an odd
  // number of edges (and they must come in pairs), we match an edge going
  // into our break node from each of them, so that we produce the first
  // part of our matching and are left with two even components.
  
  bool odd_saved = false;
  Graph odd;

  for(int i = 0; i < con_comp; i++) {
    // Making the subgraph.
    Graph sub;
    for(int n : g.nodes) {
      if(n != break_node && comp[n] == i) {
        sub.nodes.push_back(n);
      }
    }
    int cur_node = g.nodes[g.nodes.size() - 1];
    vector<int> nodes_to_add = vector<int>(0);
    for(int n : sub.nodes) {
      sub.adj[n] = vector<pair<int,int>>(0);
      for(auto p : g.adj[n]) {
        if(p.first == break_node) {
          // For edges that go to the break node, we have to add new nodes.
          cur_node++;
          nodes_to_add.push_back(cur_node);
          sub.adj[cur_node] = vector<pair<int,int>>(0);
          sub.adj[n].push_back(make_pair(cur_node, p.second));
          sub.adj[cur_node].push_back(make_pair(n, p.second));
        }
        else {
          sub.adj[n].push_back(p);
        }
        
      }
    }
    for(int n : nodes_to_add) {
      sub.nodes.push_back(n);
    }
    
    
    if(edge_ct[i] & 1) {
      if(odd_saved) {
        // This is the difficult case. We have two connected subgraphs with
        // an odd number of edges. Thus, we first find an edge from each
        // that we can match:
        odd_saved = false;
        int t1, t2;
        for(auto p : g.adj[break_node]) {
          if(comp[p.first] == comp[odd.nodes[0]]) {
            t1 = p.second;
          }
          if(comp[p.first] == comp[sub.nodes[0]]) {
            t2 = p.second;
          }
        }

        // And we output this match:
        cout << " " << t1 << "\t" << t2 << "  " << endl;
        if (t1 % 2) cout << endl;

        // Then, we remove the edges and now obsolete nodes from both
        // subgraphs.
        for(int j = 0; j < odd.nodes.size(); j++) {
          int n = odd.nodes[j];
          if(n <= g.nodes[g.nodes.size() - 1])
            continue;
          auto p = odd.adj[n][0];
          if(p.second == t1) {
            odd.nodes.erase(odd.nodes.begin() + j);
            odd.adj.erase(n);
            for(int x = 0; x < odd.adj[p.first].size(); x++) {
              if(odd.adj[p.first][x].second == t1) {
                odd.adj[p.first].erase(odd.adj[p.first].begin() + x);
                break;
              }
            }
            break;
          }
        }

        for(int j = 0; j < sub.nodes.size(); j++) {
          int n = sub.nodes[j];
          if(n <= g.nodes[g.nodes.size() - 1])
            continue;
          auto p = sub.adj[n][0];
          if(p.second == t2) {
            sub.nodes.erase(sub.nodes.begin() + j);
            sub.adj.erase(n);
            for(int x = 0; x < sub.adj[p.first].size(); x++) {
              if(sub.adj[p.first][x].second == t2) {
                sub.adj[p.first].erase(sub.adj[p.first].begin() + x);
                break;
              }
            }
            break;
          }
        }
        // The subgraphs now have an even number of edges, so we recur.
        edge_match(sub);
        edge_match(odd);
      }
      else {
        odd_saved = true;
        odd = sub;
      }
    }
    else {
      // If the subgraph has an even number of edges, we can recur
      // immediately.
      edge_match(sub);
    }
      
  }

}

int main() {
  int l, t;
  cin >> l >> t; // Number of languages, number of translators.
  // If there are an odd number of translators, it is impossible.
  if(t & 1) {
    cout << endl << "impossible";
    return 0;
  }

  // Otherwise, build the graph, and call edge_match.
  Graph g;
  g.nodes = vector<int>(l,0);
  for(int i = 0; i < l; i++) {
    g.nodes[i] = i;
    g.adj[i] = vector<pair<int,int>>(0);
  }

  for(int i = 0; i < t; i++) {
    int l1, l2;
    cin >> l1 >>  l2;
    g.adj[l1].push_back(make_pair(l2,i));
    g.adj[l2].push_back(make_pair(l1,i));
  }
  edge_match(g);
  return 0;
}
