// A solution can be found by solving a linear system over 𝔽₂, the field of
// two elements. I'll explain briefly how this is done.
// 
// Suppose first that we have a valid matching of the translators. Every
// translator has exactly one language in common with his match. If we take
// for every translator the language he has in common with his match, then
// we get a multiset of languages, each of which occurs an even number of times.
// 
// Conversely, if every translator chooses his favourite language from his two
// languages in such a way that every language is chosen an even number of
// times, then we can easily construct a matching from this: for each language
// L we simply pair up the translators who chose L.
// 
// Now how do we know if such a choice of favourite languages exists? This turns
// out to be a simple matter of linear algebra:
// 
//   * For each translator j we create a variable x[j] denoting his choice:
//     0 for the his first language in the input, 1 for the second language.
//     These variables together form a column vector x.
// 
//   * Let M denote the incidence matrix of the language graph. This is an n ⨉  m
//     matrix where M[i][j] is one if translator j speaks language i and zero
//     otherwise.
// 
//   * For each language i we let y[i] denote the number of translators that
//     have language i as their first language.
// 
// Now the variable vector x is valid if and only if Mx ≡ y (mod 2) holds.
// The proof is left as an exercise to the interested reader.
// 
// To give a simple example: if every entry in y is even, then every translator
// can simply choose his first language and we have a valid solution. In terms
// of linear algebra, we see that the equality M * 0  ≡  0  ≡  y (mod 2) holds.
// 
// This shows that the problem can be reduced to solving the linear system
// Mx = y over the field of two elements.
// 
// Current implementation complexity: O(N * M^2).
// (This can be improved upon, but this is fast enough given the bounds.)

#include <iostream>
#include <cassert>
#include <vector>

using namespace std;

const int MAX_LANGUAGES = 100;
const int MAX_TRANSLATORS = 200;

int N, M;
int languages[MAX_TRANSLATORS][2];

// store the linear system as an augmented matrix
int linearSystem[MAX_LANGUAGES][MAX_TRANSLATORS + 1];
int x[MAX_TRANSLATORS];
int rowPivot[MAX_LANGUAGES];
int colPivot[MAX_TRANSLATORS];

// print function for debugging purposes:
void printTheLinearSystem() {
	for (int i = 0; i < N; i++) {
		cerr << '[';
		for (int j = 0; j <= M; j++) {
			cerr << ' ' << linearSystem[i][j];
		}
		cerr << " ]" << endl;
	}
	cerr << endl;
}

int main() {
	// Step 1: read the input and initliaze the matrix
	cin >> N >> M;
	assert(N >= 2 && N <= MAX_LANGUAGES);
	assert(M >= 1 && M <= MAX_TRANSLATORS);
	for (int i = 0; i < N; i++) rowPivot[i] = -1;
	for (int j = 0; j < M; j++) colPivot[j] = -1;
	for (int j = 0; j < M; j++) {
		int A, B;
		cin >> A >> B;
		assert(A >= 0 && A < N);
		assert(B >= 0 && B < N);
		languages[j][0] = A;
		languages[j][1] = B;
		linearSystem[A][j] = 1;
		linearSystem[B][j] = 1;
		// the final column represents the target vector y:
		linearSystem[A][M] ^= 1;
	}
	#ifndef ONLINE_JUDGE
		printTheLinearSystem();
	#endif
	
	// Step 2: Gaussian elimination
	for (int curPivotCol = 0; curPivotCol < M; curPivotCol++) {
		int curPivotRow = -1;
		for (int i = 0; i < N; i++) {
			if (rowPivot[i] == -1 && linearSystem[i][curPivotCol] == 1) {
				curPivotRow = i;
				break;
			}
		}
		if (curPivotRow == -1) continue;
		rowPivot[curPivotRow] = curPivotCol;
		colPivot[curPivotCol] = curPivotRow;
		for (int i = 0; i < N; i++) {
			if (i == curPivotRow) continue;
			if (linearSystem[i][curPivotCol] == 1) {
				for (int j = 0; j <= M; j++) {
					linearSystem[i][j] ^= linearSystem[curPivotRow][j];
				}
			}
		}
		#ifndef ONLINE_JUDGE
			printTheLinearSystem();
		#endif
	}
	
	// Step 3: find solution vector x
	for (int j = 0; j < M; j++) x[j] = 0;
	for (int i = 0; i < N; i++) {
		if (rowPivot[i] != -1) {
			x[rowPivot[i]] = linearSystem[i][M];
		}
		else if (linearSystem[i][M] != 0) {
			cout << "impossible" << endl;
			return 0;
		}
	}
	
	// Step 4: output a matching
	vector<int> perLanguage[MAX_LANGUAGES];
	for (int j = 0; j < M; j++) {
		perLanguage[languages[j][x[j]]].push_back(j);
	}
	for (int i = 0; i < N; i++) {
		unsigned l = perLanguage[i].size();
		assert(l % 2 == 0);
		for (unsigned j = 0; j < l; j += 2) {
			cout << perLanguage[i][j] << ' ' << perLanguage[i][j + 1] << endl;
		}
	}
	return 0;
}
