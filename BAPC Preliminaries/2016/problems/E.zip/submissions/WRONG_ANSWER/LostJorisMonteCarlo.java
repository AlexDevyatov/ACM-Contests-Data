/*
 * Solution for Lost In The Woods.
 *
 * This program finds the answer by using Monte Carlo sampling.
 * This will only approximate the correct answer.
 * 
 * A Monte Carlo sample simulates a single random walk.
 * By averaging the length of such walks over many walks we obtain
 * an expected length.
 * 
 * The code is adapted from LostJoris (by Mathijs)
 */

// @EXPECTED_RESULTS@: WRONG_ANSWER, TIME_LIMIT_EXCEEDED

import java.io.*;
import java.util.*;

public class LostJorisMonteCarlo
{
    static final int MAXN = 20;
    static final int RUNS = 10000000;
    static Random random = new Random();

    public static double sim(boolean[][] graphMatrix, int[] npaths)
    {
        int n = graphMatrix.length;
        double length = 0;
    	int x = 0;
    	while( x!= n-1 ) {
    		int k = npaths[x];
    		int i = random.nextInt(k);
//    		System.out.println("x: " + x + " select nb " + i + " out of " + k);
    		int j = 0;
    		for( ; j < n && i >= 0; j++)
    			if (graphMatrix[j][x])
    			{
    				i--;
    			}
    		length++;
    		x = j-1;
    	}
    	return length;
    }

    
    // Calculate final answer from connectivity matrix of graph.
    public static double solve(boolean[][] graphMatrix)
    {
        int n = graphMatrix.length;
        int[] npaths = new int[n];

        // Construct matrix B with transition probabilities.
        double[][] probMatrix = new double[n-1][n-1];
        for (int x = 0; x < n-1; x++) {
            int npath = 0;
            for (int i = 0; i < n; i++) {
                if (graphMatrix[i][x]) {
                    npath++;
                }
            }
            npaths[x] = npath;
            assert(npath > 0);
//            for (int i = 0; i < n-1; i++) {
//                probMatrix[i][x] = graphMatrix[i][x] ?
//                                     (1.0 / (double)npath) : 0.0;
//            }
        }
        double length = 0;
        for(int i = 0; i < RUNS; ++i )
        	length += sim( graphMatrix, npaths );

        // Return final answer.
        return length / (double) RUNS;
    }
  

    // Main program.
    public static void main(String[] args)
    {
        try {
            BufferedReader ir = new BufferedReader(
                                  new InputStreamReader(System.in));

            // Read integers N and M.
            String s = ir.readLine();
            String[] w = s.split(" ");
            assert(w.length == 2);
            int n = Integer.parseInt(w[0]);
            int m = Integer.parseInt(w[1]);
            assert(n >= 2 && n <= MAXN);
            assert(m >= 1);

            // Read paths and create connectivity matrix.
            boolean[][] graphMatrix = new boolean[n][n];
            for (int p = 0; p < m; p++) {
                s = ir.readLine();
                w = s.split(" ");
                assert(w.length == 2);
                int x = Integer.parseInt(w[0]);
                int y = Integer.parseInt(w[1]);
                assert(x >= 0 && x < n);
                assert(y >= 0 && y < n);
                assert(x != y);
                assert(!graphMatrix[x][y]);
                graphMatrix[x][y] = true;
                graphMatrix[y][x] = true;
            }

            // Check end-of-file.
            s = ir.readLine();
            assert(s == null);

            // Solve problem.
            double ans = solve(graphMatrix);

            // Write output.
            System.out.println(String.format(Locale.US, "%.8f", ans));

        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}
