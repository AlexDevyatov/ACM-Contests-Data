/*
 * Incorrect solution for Lost In The Woods.
 *
 * This program uses Monte-Carlo simulation of many random walks
 * to estimate the average number of steps.
 *
 * This could work in principle, but the program performs too few
 * simulations to get an accurate result.
 */

#include <assert.h>
#include <stdio.h>
#include <random>
#include <vector>


static constexpr int MAXN = 20;
static constexpr int NSIMULATIONS = 500000;


int main()
{
    int n = -1, m = -1;
    scanf("%d %d", &n, &m);
    assert(n >= 2 && n <= MAXN);
    assert(m >= 1);

    std::vector<std::vector<int>> edges(n);
    for (int p = 0; p < m; p++) {
        int k = -1, l = -1;
        scanf("%d %d", &k, &l);
        assert(k >= 0 && k < n);
        assert(l >= 0 && l < n);
        assert(k != l);
        edges[k].push_back(l);
        edges[l].push_back(k);
    }

    std::mt19937 randgen(std::mt19937::default_seed);
    std::uniform_real_distribution<> randdist(0.0, 1.0);

    long sumsteps = 0;

    for (int i = 0; i < NSIMULATIONS; i++) {
        int p = 0;
        while (p != n - 1) {
            sumsteps++;
            double r = randdist(randgen);
            int q = int(r * edges[p].size());
            assert(q >= 0 && q < edges[p].size());
            p = edges[p][q];
        }
    }

    double avgsteps = double(sumsteps) / double(NSIMULATIONS);
    printf("%.6f\n", avgsteps);

    return 0;
}

