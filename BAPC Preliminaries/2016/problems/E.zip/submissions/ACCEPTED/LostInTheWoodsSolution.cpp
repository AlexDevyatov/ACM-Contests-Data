#include <iostream>
#include <algorithm>
#include <cstdio>

using namespace std;

int main() {
  // Build the graph.
  int n, m;
  cin >> n >> m;
  vector<vector<int>> adj(n);

  for(int i = 0; i < m; i++) {
    int a, b;
    cin >> a >> b;
    adj[a].push_back(b);
    adj[b].push_back(a);
  }

  // Put all the probability weight at the point where Bob got lost.
  vector<double> weight(n,0.0);
  weight[0] = 1.0;
  int step = 0;
  double ex = 0.0;

  // Each step:
  for(int x = 0; x < 10000; x++) {
    step++;
    vector<double> new_weight(n,0.0);

    // Redistribute the probability weight.
    for(int i = 0; i < n; i++) {
      for(int j : adj[i]) {
        new_weight[j] += weight[i]/adj[i].size();
      }
    }

    // Update the expected value.
    ex += step * new_weight[n-1];
    new_weight[n-1] = 0.0;
    weight = new_weight;
  }
  printf("%.7lf\n",ex);
}
