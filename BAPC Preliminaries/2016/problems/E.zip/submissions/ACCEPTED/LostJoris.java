/*
 * Solution for Lost In The Woods.
 *
 * This program finds the answer in one step by solving a system
 * of linear equations. It does not use step-by-step simulation
 * of the random walk.
 *
 * The random process of walking through the woods can be
 * represented as a N-by-N matrix A, where A(y,x) represents
 * the probability of going to clearing y at time t+1 given
 * that you were at clearing x at time t.
 *
 * We construct a vector v such that v(x) is the expected number
 * of steps to reach the exit when starting at clearing x.
 *
 * The following is known about vector v:
 *
 *   - Its last element is zero (no steps are needed when starting
 *     at the exit).
 *
 *       v(n-1) = 0
 *
 *   - For any other clearing, the expected number of steps is
 *     1 plus the probability-weighted sum of expected number of steps
 *     from the next possible locations:
 *
 *       v(x) = 1 + Sum{ v(i) * A(i,x) }
 *
 *       v = [ 1, 1, ... 1, 0 ] + v * A
 *
 * Define vector w as the first n-1 elements of v,
 * and matrix B as the upper-left (n-1)-by-(n-1) submatrix of A.
 * The above leads directly to the following system of linear equations:
 *
 *   w = w * B + [ 1, 1, ... 1 ]
 *
 *   w * (I - B) = [ 1, 1, ... 1 ]
 *
 * This system has a unique solution (if the original graph was connected,
 * matrix (I-B) is strictly diagonally dominant and thus invertible).
 * The solution is found by Gaussian eleminition in time O(N**3).
 * The final answer to the problem is simply the first element w(0).
 *
 * This program is not faster than step-by-step simulation, but it produces 
 * the answer at full accuracy.
 */

// @EXPECTED_RESULTS@: CORRECT

import java.io.*;
import java.util.*;

public class LostJoris
{
    static final int MAXN = 20;


    // Solve linear system of equations M * x = rhs and return x.
    // Matrix M must be square and invertible.
    public static double[] solveLinear(double[][] m, double[] rhs)
    {
        int n = m.length;

        assert(n > 0);
        for (int i = 0; i < n; i++) {
            assert(m[i].length == n);
        } 
        assert(rhs.length == n);

        // Make temporary copy of input data.
        m = Arrays.copyOf(m, n);
        for (int i = 0; i < n; i++) {
            m[i] = Arrays.copyOf(m[i], n);
        }
        rhs = Arrays.copyOf(rhs, n);

        int[] pivot = new int[n];
        boolean[] pivot_used = new boolean[n];

        // Forward elimination.
        for (int k = 0; k < n; k++) {

            // Bring previously pivoted columns to zero.
            for (int i = 0; i < k; i++) {
                int p = pivot[i];
                double a = m[k][p];
                for (int x = 0; x < n; x++) {
                    m[k][x] -= a * m[i][x];
                }
                rhs[k] -= a * rhs[i];
            }

            // Select new pivot column.
            double maxpmag = -1;
            for (int p = 0; p < n; p++) {
                if (!pivot_used[p]) {
                    double pmag = Math.abs(m[k][p]);
                    if (pmag > maxpmag) {
                        maxpmag = pmag;
                        pivot[k] = p;
                    }
                }
            }
            assert(maxpmag > 0);
            pivot_used[pivot[k]] = true;

            // Divide row by pivot.
            double a = m[k][pivot[k]];
            for (int x = 0; x < n; x++) {
                m[k][x] = m[k][x] / a;
            }
            rhs[k] = rhs[k] / a;
        }

        // Back substitution.
        double[] w = new double[n];
        for (int k = n-1; k >= 0; k--) {
            double a = rhs[k];
            for (int i = k + 1; i < n; i++) {
                a -= w[pivot[i]] * m[k][pivot[i]];
            }
            w[pivot[k]] = a;
        }

        return w;
    }


    // Calculate final answer from connectivity matrix of graph.
    public static double solve(boolean[][] graphMatrix)
    {
        int n = graphMatrix.length;

        // Construct matrix B with transition probabilities.
        double[][] probMatrix = new double[n-1][n-1];
        for (int x = 0; x < n-1; x++) {
            int npath = 0;
            for (int i = 0; i < n; i++) {
                if (graphMatrix[i][x]) {
                    npath++;
                }
            }
            assert(npath > 0);
            for (int i = 0; i < n-1; i++) {
                probMatrix[i][x] = graphMatrix[i][x] ?
                                     (1.0 / (double)npath) : 0.0;
            }
        }

        // Construct matrix M = transposed (I - B).
        double[][] m = new double[n-1][n-1];
        for (int y = 0; y < n-1; y++) {
            for (int x = 0; x < n-1; x++) {
                m[y][x] = (y == x) ? 1.0 : (-probMatrix[x][y]);
            }
        }

        // Solve M * w = [ 1, 1, ... 1 ]
        double[] rhs = new double[n-1];
        for (int y = 0; y < n-1; y++) {
            rhs[y] = 1.0;
        }

        double[] w = solveLinear(m, rhs);

        // Sanity check on result.
        for (int y = 0; y < n-1; y++) {
            assert(w[y] > 0);
        }

        // Return final answer.
        return w[0];
    }


    // Check that graph is connected.
    // This function is not needed to solve the problem,
    // its only purpose is input checking.
    public static boolean connectedGraph(boolean[][] graphMatrix)
    {
        int n = graphMatrix.length;
        boolean[] reached = new boolean[n];
        ArrayDeque<Integer> queue = new ArrayDeque<Integer>();

        reached[0] = true;
        queue.add(0);

        while (!queue.isEmpty()) {
            int k = queue.poll();
            for (int i = 0; i < n; i++) {
                if (!reached[i] && graphMatrix[i][k]) {
                    reached[i] = true;
                    queue.add(i);
                }
            }
        }

        for (int i = 0; i < n; i++) {
            if (!reached[i]) {
                return false;
            }
        }
        return true;
    }


    // Main progrmam.
    public static void main(String[] args)
    {
        try {
            BufferedReader ir = new BufferedReader(
                                  new InputStreamReader(System.in));

            // Read integers N and M.
            String s = ir.readLine();
            String[] w = s.split(" ");
            assert(w.length == 2);
            int n = Integer.parseInt(w[0]);
            int m = Integer.parseInt(w[1]);
            assert(n >= 2 && n <= MAXN);
            assert(m >= 1);

            // Read paths and create connectivity matrix.
            boolean[][] graphMatrix = new boolean[n][n];
            for (int p = 0; p < m; p++) {
                s = ir.readLine();
                w = s.split(" ");
                assert(w.length == 2);
                int x = Integer.parseInt(w[0]);
                int y = Integer.parseInt(w[1]);
                assert(x >= 0 && x < n);
                assert(y >= 0 && y < n);
                assert(x != y);
                assert(!graphMatrix[x][y]);
                graphMatrix[x][y] = true;
                graphMatrix[y][x] = true;
            }

            // Check end-of-file.
            s = ir.readLine();
            assert(s == null);

            // Check that graph is connected.
            assert(connectedGraph(graphMatrix));

            // Solve problem.
            double ans = solve(graphMatrix);

            // Write output.
            System.out.println(String.format(Locale.US, "%.8f", ans));

        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}
