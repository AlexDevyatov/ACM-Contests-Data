#include <iostream>
#include <cassert>

using namespace std;

struct point {
	long long x, y;
	
	// Adding and subtracting points:
	point& operator+=(const point& other) {
		x += other.x;
		y += other.y;
		return *this;
	}
	point operator+(const point& other) const {
		return point(*this) += other;
	}
	point& operator-=(const point& other) {
		x -= other.x;
		y -= other.y;
		return *this;
	}
	point operator-(const point& other) const {
		return point(*this) -= other;
	}
	
	// Inner product:
	long long operator*(const point& other) const {
		return x * other.x + y * other.y;
	}
	
	// Input and output:
	friend istream& operator>>(istream& is, point& p) {
		return is >> p.x >> p.y;
	}
	friend ostream& operator<<(ostream& os, const point& p) {
		return os << p.x << ' ' << p.y;
	}
};


int main() {
	point A, B, C;
	cin >> A >> B >> C;
	if ((A - C) * (B - C) == 0) {
		cout << A + B - C << endl;
	}
	else if ((A - B) * (C - B) == 0) {
		cout << A + C - B << endl;
	}
	else if ((B - A) * (C - A) == 0) {
		cout << B + C - A << endl;
	}
	else {
		cerr << "Something went wrong! This should not have happened..." << endl;
		assert(false);
	}
	return 0;
}
