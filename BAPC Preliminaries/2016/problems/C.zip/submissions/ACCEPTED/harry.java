import java.io.Console;
import java.util.Scanner;

public class harry
{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int ax = sc.nextInt();
		int ay = sc.nextInt();
		int bx = sc.nextInt();
		int by = sc.nextInt();
		int cx = sc.nextInt();
		int cy = sc.nextInt();
		
		int dx, dy; //The answer.
		
		while((bx-ax)*(cx-ax) + (by-ay)*(cy-ay) != 0)
		{
			int oldax = ax, olday = ay;
			ax = bx; ay = by; bx = cx; by = cy; cx = oldax; cy = olday; 
			
		}
		dx = bx + cx - ax; dy = by + cy - ay;
		System.out.println(dx + " " + dy);
	}
}