#include <iostream>
#include <cassert>

using namespace std;

#define SQ(x) ((x) * (x))

struct point {
	long long x, y;
	
	// Compute the square of the distance between two points:
	long long sqdist(const point& other) const {
		return SQ(x - other.x) + SQ(y - other.y);
	}
	
	// Adding and subtracting points:
	point& operator+=(const point& other) {
		x += other.x;
		y += other.y;
		return *this;
	}
	point operator+(const point& other) const {
		return point(*this) += other;
	}
	point& operator-=(const point& other) {
		x -= other.x;
		y -= other.y;
		return *this;
	}
	point operator-(const point& other) const {
		return point(*this) -= other;
	}
	
	// Input and output:
	friend istream& operator>>(istream& is, point& p) {
		return is >> p.x >> p.y;
	}
	friend ostream& operator<<(ostream& os, const point& p) {
		return os << p.x << ' ' << p.y;
	}
};

int main() {
	point A, B, C;
	cin >> A >> B >> C;
	int safetyCounter = 0;
	while (A.sqdist(B) != A.sqdist(C)) {
		swap(A, C);
		swap(B, C);
		assert(safetyCounter++ < 10);
	}
	point D = B + C - A;
	cout << D << endl;
	return 0;
}
