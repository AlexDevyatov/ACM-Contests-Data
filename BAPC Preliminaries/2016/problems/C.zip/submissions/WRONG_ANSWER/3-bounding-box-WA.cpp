// Basic idea: Try three possible candidates for the fourth corner of the square.
//             
//             If the four points lie inside a square bounding box, then the
//             (optimistic) assumption is that these four must form a square.
//             See function makes_for_a_square_bounding_box below.
//             
//             An example of a test case that fails is when the input consists
//             of the points (0,0), (1,3) and (4,2). Indeed, now the sum (5,5)
//             makes for a square bounding box, but the resulting figure is not
//             a square.

#include <iostream>

using namespace std;

struct point {
	int x, y;
	point() {}
	point(int _x, int _y) : x(_x), y(_y) {}
	
	point& operator+=(const point& other) {
		x += other.x;
		y += other.y;
		return *this;
	}
	point operator+(const point& other) const {
		return point(*this) += other;
	}
	
	point& operator-=(const point& other) {
		x -= other.x;
		y -= other.y;
		return *this;
	}
	point operator-(const point& other) const {
		return point(*this) -= other;
	}
	
	friend istream& operator>>(istream& is, point& p) {
		is >> p.x >> p.y;
		return is;
	}
	friend ostream& operator<<(ostream& os, const point& p) {
		os << p.x << ' ' << p.y;
		return os;
	}
};

bool makes_for_a_square_bounding_box(point A, point B, point C, point D) {
	int minX = min(min(A.x, B.x), min(C.x, D.x));
	int maxX = max(max(A.x, B.x), max(C.x, D.x));
	int minY = min(min(A.y, B.y), min(C.y, D.y));
	int maxY = max(max(A.y, B.y), max(C.y, D.y));
	return maxX - minX == maxY - minY;
}

int main() {
	point A, B, C;
	cin >> A >> B >> C;
	point p[] = {A + B - C,
	             B + C - A,
	             C + A - B  };
	for (int i = 0; i < 3; i++) {
		if (makes_for_a_square_bounding_box(A, B, C, p[i])) {
			cout << p[i] << endl;
		}
	}
	return 0;
}
