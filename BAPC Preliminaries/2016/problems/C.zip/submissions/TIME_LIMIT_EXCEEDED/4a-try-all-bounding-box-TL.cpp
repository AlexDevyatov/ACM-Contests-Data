// Basic idea: try every conceivable fourth point and check to see if it fits.
// 
// This check is done by looking at the bounding box, which has to look like
// the following familiar picture from the proof of the Pythagoream Theorem:
// https://commons.wikimedia.org/wiki/File:Pythagorean_Theorem_Proof.png
// Recognising this bounding box is doable.
// 
// This solution should however exceed the time limit, since trying all those
// points is way more work than necessary.

#include <iostream>
#include <cassert>
#include <cstdlib>

using namespace std;

struct point {
	int x, y;
	point() {}
	point(int _x, int _y) : x(_x), y(_y) {}
	
	friend istream& operator>>(istream& is, point& p) {
		is >> p.x >> p.y;
		return is;
	}
	friend ostream& operator<<(ostream& os, const point& p) {
		os << p.x << ' ' << p.y;
		return os;
	}
};

point min(const point& p, const point& q) {
	return point(min(p.x, q.x), min(p.y, q.y));
}

point max(const point& p, const point& q) {
	return point(max(p.x, q.x), max(p.y, q.y));
}

bool tryFourPoints(const point& A, const point& B, const point& C, const point& D) {
	// Step 1: Check to see if the bounding box for these four points is a square.
	point pMin = min(min(A, B), min(C, D));
	point pMax = max(max(A, B), max(C, D));
	if (pMax.x - pMin.x != pMax.y - pMin.y) return false;
	int boundingBoxSize = pMax.x - pMin.x;
	
	// Step 2: Check that each of the four points {A, B, C, D} lies on a border, and
	//         every border contains the same number of points (either all borders have
	//         one point or all borders have two points).
	//         
	//         The borders are indexed in positive orientation (counterclockwise):
	//           ==>  0 denotes the right border (maximum x coordinate);
	//           ==>  1 denotes the top border (maximum y coordinate);
	//           ==>  2 denotes the left border (minimum x coordinate);
	//           ==>  3 denotes the bottom border (minimum y coordinate).
	int borderCount[] = {0, 0, 0, 0};
	int borderIndex[] = {-1, -1, -1, -1};
	point p[] = {A, B, C, D};
	for (int i = 0; i < 4; i++) {
		if (p[i].x != pMin.x && p[i].x != pMax.x && p[i].y != pMin.y && p[i].y != pMax.y) return false;
		if (p[i].x == pMax.x) {
			borderCount[0]++;
			borderIndex[0] = i;
		}
		if (p[i].y == pMax.y) {
			borderCount[1]++;
			borderIndex[1] = i;
		}
		if (p[i].x == pMin.x) {
			borderCount[2]++;
			borderIndex[2] = i;
		}
		if (p[i].y == pMin.y) {
			borderCount[3]++;
			borderIndex[3] = i;
		}
	}
	if (borderCount[0] != borderCount[1] || borderCount[1] != borderCount[2] || borderCount[2] != borderCount[3]) return false;
	
	// Step 3: Recognise if the input forms a square with sides parallel to the coordinate axes.
	if (borderCount[0] == 2) return true;
	
	// Step 4: Otherwise, every side of the bounding box contains exactly one of the points {A, B, C, D}.
	//         Now we compute the a and b values from the image.
	// 
	//         (Strictly speaking, we only need to compute one of these. The other one is included here for clarity.)
	assert(borderCount[0] == 1);
	assert(borderIndex[0] != -1 && borderIndex[1] != -1 && borderIndex[2] != -1 && borderIndex[3] != -1);
	int refA[] = {pMin.y, pMax.x, pMax.y, pMin.x};
	int refB[] = {pMax.y, pMin.x, pMin.y, pMax.x};
	int a[4], b[4];
	for (int i = 0; i < 4; i++) {
		point& cur = p[borderIndex[i]];
		int coord = (i % 2 ? cur.x : cur.y);
		a[i] = abs(coord - refA[i]);
		b[i] = abs(coord - refB[i]);
		assert(a[i] + b[i] == boundingBoxSize);
	}
	return a[0] == a[1] && a[1] == a[2] && a[2] == a[3] && b[0] == b[1] && b[1] == b[2] && b[2] == b[3];
}

int main() {
	point A, B, C;
	cin >> A >> B >> C;
	for (int x = -20000; x <= 20000; x++) {
		int startY = -20000 + abs(x);
		int endY = 20000 - abs(x);
		for (int y = startY; y <= endY; y++) {
			point D(x, y);
			if (tryFourPoints(A, B, C, D)) {
				cout << D << endl;
				return 0;
			}
		}
	}
	return 1;
}
