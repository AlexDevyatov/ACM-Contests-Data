// Basic idea: try every conceivable fourth point and check to see if it fits.
// 
// This check is done by looking at the pairwise distances, six in total. If
// four of these coincide, then we must have a square. (Here we use the fact
// that there doesn't exist an equilateral triangle with integer coordinates.)
// 
// This solution should however exceed the time limit, since trying all those
// points is way more work than necessary.

#include <iostream>
#include <algorithm>

using namespace std;

int SQ(int x) { return x * x; }

struct point {
	int x, y;
	point() {}
	point(int _x, int _y) : x(_x), y(_y) {}
	
	long long sqdist(const point& other) const {
		return SQ(x - other.x) + SQ(y - other.y);
	}
	
	friend istream& operator>>(istream& is, point& p) {
		is >> p.x >> p.y;
		return is;
	}
	friend ostream& operator<<(ostream& os, const point& p) {
		os << p.x << ' ' << p.y;
		return os;
	}
};

point min(const point& p, const point& q) {
	return point(min(p.x, q.x), min(p.y, q.y));
}

point max(const point& p, const point& q) {
	return point(max(p.x, q.x), max(p.y, q.y));
}

int d[] = {0, 0, 0, 0, 0, 0};

bool tryFourPoints(const point& A, const point& B, const point& C, const point& D) {
	point p[] = {A, B, C, D};
	int k = 3;
	for (int i = 0; i < 3; i++) {
		d[k++] = D.sqdist(p[i]);
	}
	int minD = d[0];
	for (int i = 1; i < 6; i++) {
		minD = min(minD, d[i]);
	}
	int c = 0;
	for (int i = 0; i < 6; i++) {
		c += (d[i] == minD ? 1 : 0);
	}
	return c == 4;
}

int main() {
	point A, B, C;
	cin >> A >> B >> C;
	d[0] = A.sqdist(B);
	d[1] = A.sqdist(C);
	d[2] = B.sqdist(C);
	for (int x = -20000; x <= 20000; x++) {
		int startY = -20000 + abs(x);
		int endY = 20000 - abs(x);
		for (int y = startY; y <= endY; y++) {
			point D(x, y);
			if (tryFourPoints(A, B, C, D)) {
				cout << D << endl;
				return 0;
			}
		}
	}
	return 1;
}
