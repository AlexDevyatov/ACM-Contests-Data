// This solution is fine, but not very readable. It is cluttered with asserts
// and additional debug output. This solution serves mostly for jury testing.
// 
// A cleaned up version of this solution has been made which is more suitable
// as a reference solution; see 2-knapsack-cleanedup-AC.cpp.

#include <iostream>
#include <cassert>
#include <algorithm>

using namespace std;

const int MAX_CASES = 100;
const int MAX_DELEGATES = 2016;
const int MAX_STATES = MAX_DELEGATES;
const int MAX_VOTERS = 1000000000;

const int MY_INFINITY = MAX_VOTERS + 100;

int D[MAX_STATES], C[MAX_STATES], F[MAX_STATES], U[MAX_STATES];
int dp[MAX_DELEGATES + 1];

int findMajority(int x) {
	return (x / 2) + 1;
}

int main() {
	int S;
	cin >> S;
	assert(S >= 1 && S <= MAX_STATES);
	fill_n(dp, MAX_DELEGATES + 1, MY_INFINITY);
	dp[0] = 0;
	int totalDelegates = 0;
	int totalVoters = 0;
	for (int i = 0; i < S; i++) {
		cin >> D[i] >> C[i] >> F[i] >> U[i];
		assert(D[i] >= 1 && D[i] <= MAX_DELEGATES);
		totalDelegates += D[i];
		assert(totalDelegates >= 1 && totalDelegates <= MAX_DELEGATES);
		assert(C[i] >= 0 && C[i] <= MAX_VOTERS);
		assert(F[i] >= 0 && F[i] <= MAX_VOTERS);
		assert(U[i] >= 0 && U[i] <= MAX_VOTERS);
		int stateVoters = C[i] + F[i] + U[i];
		assert(stateVoters >= 1 && stateVoters <= MAX_VOTERS);
		totalVoters += stateVoters;
		assert(totalVoters >= 1 && totalVoters <= MAX_VOTERS);
	}
	int delegatesNeeded = findMajority(totalDelegates);
	
	// Finished reading input, starting actual solution:
	int ans = MY_INFINITY;
	for (int i = 0; i < S; i++) {
		int stateVoters = C[i] + F[i] + U[i];
		int neededToWin = findMajority(stateVoters);
		int needToConvince = max(neededToWin - C[i], 0);
		if (needToConvince > U[i]) {
			#ifdef DEBUG
				cerr << "  state " << i + 1 << " cannot be won." << endl;
			#endif
			continue;
		}
		for (int j = totalDelegates; j >= D[i]; j--) {
			dp[j] = min(dp[j], dp[j - D[i]] + needToConvince);
			if (j >= delegatesNeeded) {
				ans = min(ans, dp[j]);
			}
		}
	}
	#ifdef DEBUG
		cerr << " ";
		for (int i = 0; i <= totalDelegates; i++) {
			cerr << " ";
			if (dp[i] != MY_INFINITY) cerr << dp[i];
			else cerr << "X";
		}
		cerr << endl;
	#endif
	if (ans == MY_INFINITY) {
		cout << "impossible" << endl;
	}
	else {
		cout << ans << endl;
	}
	return 0;
}
