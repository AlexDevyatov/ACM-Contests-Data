// This is the model solution.
// 
// The problem is a variation on the 0-1 knapsack problem. It can be solved
// in O(S * T) time using O(T) memory by applying the same dynamic programming
// solution as is used for the original 0-1 knapsack problem. (Here S denotes
// the number of states and T denotes the total number of delegates.)

#include <iostream>
#include <algorithm>

using namespace std;

const int MY_INFINITY = 1000000001;

int dp[2017];

int findMajority(int x) {
	return (x / 2) + 1;
}

int main() {
	// Initialisation:
	int totalDelegates = 0;
	fill_n(dp, 2017, MY_INFINITY);
	dp[0] = 0;
	
	// Read input, knapsack:
	int S;
	cin >> S;
	for (int i = 0; i < S; i++) {
		int D, C, F, U;
		cin >> D >> C >> F >> U;
		totalDelegates += D;
		int stateVoters = C + F + U;
		
		int majority = findMajority(stateVoters);
		int leftToConvince = max(majority - C, 0);
		if (leftToConvince > U) {
			// There is no way to win this state.
			continue;
		}
		
		// To win this state, we still have to convince <leftToConvince> undecided voters.
		// In terms of knapsack: we have an item with cost leftToConvince and value D.
		for (int j = totalDelegates; j >= D; j--) {
			dp[j] = min(dp[j], dp[j - D] + leftToConvince);
		}
	}
	
	// Find the answer by looking through our knapsack array:
	int ans = MY_INFINITY;
	int delegatesNeeded = findMajority(totalDelegates);
	for (int j = delegatesNeeded; j <= totalDelegates; j++) {
		ans = min(ans, dp[j]);
	}
	
	// Output the final answer:
	if (ans == MY_INFINITY) {
		cout << "impossible" << endl;
	}
	else {
		cout << ans << endl;
	}
	return 0;
}
