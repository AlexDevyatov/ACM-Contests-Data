/*
    Solution in Java of Presidential Elections
    a problem for BAPC2016
    author: Peter Kluit
    September 2016

 */

import java.util.*;  

public class Elections{
   static Scanner ir ;
   private static int INF = Integer.MAX_VALUE;

   public static void main (String args[]){
       ir = new Scanner(System.in);
       run();
   }

   private static void run(){

      int states = ir.nextInt();
      Elections el = new Elections();
      for (int k = 0; k < states; k++){
          int d = ir.nextInt();
          int c = ir.nextInt();
          int f = ir.nextInt();
          int u = ir.nextInt();
          el.addState(d,c,f,u);
      }
      int votes = el.votes();
      if (votes == INF)
         System.out.println("impossible");
      else 
         System.out.println(votes);
   }

//////////////////////////////////////////
   private int delegates;
   private int [] price = new int [2017];

   public Elections (){
      for (int k = 1; k <= 2016; k++)
         price[k] = INF;
   }

   public void addState(int d, int c, int f, int u){
      int allVotes = c + f + u;
      int majority = (allVotes + 2)/2;
      int needed = majority - c;
      if (needed <= u){
         for (int dd = delegates; dd >= 0; dd--)
            if (price[dd] <  INF)
               update(dd + d, needed + price[dd]);
      }
      delegates += d;
   }

   private void update(int d, int p){
       if (price[d] > p)
          price[d] = p;
   }

   public int votes(){
       int result = INF;
       int majority = (delegates + 2) / 2;
       for (int dd = majority; dd <= delegates; dd++)
          if (price[dd] < result){
             result = price[dd];
          }
       return result;
   }

}

