// This is a slight variation on the reference solution. This particular
// solution fails by having an array that is just one element too short.
// 
// The array is not properly initialised, so we end up going out of bounds. On
// my machine, a value of zero is read, which messes up the final answer.

#include <iostream>
#include <algorithm>

using namespace std;

const int MY_INFINITY = 1000000001;

int dp[2016]; // <-- array too short, WRONG ANSWER!

int findMajority(int x) {
	return (x / 2) + 1;
}

int main() {
	// Initialisation:
	int totalDelegates = 0;
	fill_n(dp, 2016, MY_INFINITY); // <-- initialisation also too short
	dp[0] = 0;
	
	// Read input, knapsack:
	int S;
	cin >> S;
	for (int i = 0; i < S; i++) {
		int D, C, F, U;
		cin >> D >> C >> F >> U;
		totalDelegates += D;
		int stateVoters = C + F + U;
		
		int majority = findMajority(stateVoters);
		int leftToConvince = max(majority - C, 0);
		if (leftToConvince > U) {
			// There is no way to win this state.
			continue;
		}
		
		// To win this state, we still have to convince <leftToConvince> undecided voters.
		// In terms of knapsack: we have an item with cost leftToConvince and value D.
		for (int j = totalDelegates; j >= D; j--) {
			dp[j] = min(dp[j], dp[j - D] + leftToConvince);
		}
	}
	
	// Find the answer by looking through our knapsack array:
	int ans = MY_INFINITY;
	int delegatesNeeded = findMajority(totalDelegates);
	for (int j = delegatesNeeded; j <= totalDelegates; j++) {
		ans = min(ans, dp[j]); // <-- we might go out of our array here, possibly into unallocated memory
	}
	
	// Output the final answer:
	if (ans == MY_INFINITY) {
		cout << "impossible" << endl;
	}
	else {
		cout << ans << endl;
	}
	return 0;
}
