// This is a slight variation on the reference solution.
// 
// The formula for calculating the majority (both on the state and national
// levels) is now implemented using floats, which results in rounding errors.

#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;

const int MY_INFINITY = 1000000001;

int dp[2017];

int findMajority(float x) {
	return (int) (floor(x / 2.0f) + 1.0f); // <-- rounding errors
}

int main() {
	// Initialisation:
	int totalDelegates = 0;
	fill_n(dp, 2017, MY_INFINITY);
	dp[0] = 0;
	
	// Read input, knapsack:
	int S;
	cin >> S;
	for (int i = 0; i < S; i++) {
		int D, C, F, U;
		cin >> D >> C >> F >> U;
		totalDelegates += D;
		int stateVoters = C + F + U;
		
		int majority = findMajority(stateVoters);
		int leftToConvince = max(majority - C, 0);
		if (leftToConvince > U) {
			// There is no way to win this state.
			continue;
		}
		
		// To win this state, we still have to convince <leftToConvince> undecided voters.
		// In terms of knapsack: we have an item with cost leftToConvince and value D.
		for (int j = totalDelegates; j >= D; j--) {
			dp[j] = min(dp[j], dp[j - D] + leftToConvince);
		}
	}
	
	// Find the answer by looking through our knapsack array:
	int ans = MY_INFINITY;
	int delegatesNeeded = findMajority(totalDelegates);
	for (int j = delegatesNeeded; j <= totalDelegates; j++) {
		ans = min(ans, dp[j]);
	}
	
	// Output the final answer:
	if (ans == MY_INFINITY) {
		cout << "impossible" << endl;
	}
	else {
		cout << ans << endl;
	}
	return 0;
}
