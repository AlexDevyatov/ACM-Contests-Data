/*
 * Incorrect solution to Hamming Ellipses
 *
 * This program hits numeric overflow during calculation of binomial
 * coefficients.
 */

// @EXPECTED_RESULTS@: WRONG-ANSWER

#include <stdio.h>
#include <vector>

using namespace std;


/* Calculate binomial coefficient. */
long long binom(int n, int k)
{
    long long b = 1;
    for (int i = n-k+1; i <= n; i++) {
        b *= i;
    }
    for (int i = 1; i <= k; i++) {
        b /= i;
    }
    return b;
}


/* Calculate hamming distance between words f1 and f2. */
int hamming_distance(const vector<int>& f1, const vector<int>& f2)
{
    int d = 0;
    for (int i = 0, n = f1.size(); i < n; i++) {
        if (f1[i] != f2[i]) {
            d++;
        }
    }
    return d;
}


/* Solve the problem. */
long long solve(int q, int n, int d,
                const vector<int>& f1, const vector<int>& f2)
{
    int fdist = hamming_distance(f1, f2);

    if (q == 1) {
        return (d == 0) ? 1 : 0;
    }

    long long ans = 0;

    for (int k = 0; k <= fdist; k++) {

        if (q == 2 && k > 0) {
            continue;
        }

        int u = d - fdist - k;
        if (u < 0 || u % 2 != 0 || u/2 > n - fdist) {
            continue;
        }

        int p = u / 2;

        long long a = binom(fdist, k);

        for (int i = 0; i < fdist-k; i++) {
            a *= 2;
        }

        for (int i = 0; i < k; i++) {
            a *= (q-2);
        }

        a *= binom(n-fdist, p);

        for (int i = 0; i < p; i++) {
            a *= (q-1);
        }

        ans += a;
    }

    return ans;
}


/* Main program. */
int main(void)
{
    // Read input.
    int q = -1, n = -1, d = -1;
    scanf("%d %d %d", &q, &n, &d);

    vector<int> f1(n);
    vector<int> f2(n);

    for (vector<int> *v : { &f1, &f2 }) {
        scanf(" ");
        for (int i = 0; i < n; i++) {
            int c;
            c = fgetc(stdin);
            c -= '0';
            v->at(i) = c;
        }
    }

    // Solve problem.
    long long ans = solve(q, n, d, f1, f2);

    // Write output.
    printf("%lld\n", ans);

    return 0;
}

// end
