/*
 * Incorrect solution to Hamming Ellipses
 *
 * Algorithm: Enumerate every choice of positions where the point
 * is equal/different from the focal points, then add the number
 * of such points.
 *
 * This program can only produce answers up to 2**63 - 1.
 *
 * Time complexity O(2**n).
 */

// @EXPECTED_RESULTS@: TIMELIMIT

#include <stdio.h>
#include <assert.h>
#include <initializer_list>

using namespace std;


static int f1[10000];
static int f2[10000];


static long long solve_rec(int q, int n, int d, int p)
{
    if (p == n) {
        return (d == 0) ? 1 : 0;
    }

    if (d > 2 * (n - p)) {
        return 0;
    }

    long long a = 0;

    if (f1[p] == f2[p]) {

        a += solve_rec(q, n, d, p+1);

        if (d >= 2) {
            a += (q-1) * solve_rec(q, n, d-2, p+1);
        }

    } else {

        if (d >= 1) {
            a += 2 * solve_rec(q, n, d-1, p+1);
        }

        if (d >= 2 && q > 2) {
            a += (q-2) * solve_rec(q, n, d-2, p+1);
        }

    }

    return a;
}


/* Main program. */
int main(void)
{
    // Read input.
    int q, n, d;
    scanf("%d %d %d", &q, &n, &d);

    for (int *v : { f1, f2 }) {
        scanf(" ");
        for (int i = 0; i < n; i++) {
            int c;
            c = fgetc(stdin);
            assert(c >= '0' && c <= '9');
            c -= '0';
            assert(c >= 0 && c < q);
            v[i] = c;
        }
    }

    // Solve problem.
    long long ans = solve_rec(q, n, d, 0);

    // Write output.
    printf("%lld\n", ans);

    return 0;
}

// end
