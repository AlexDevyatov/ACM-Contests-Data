/* solution in Java
   for problem Hamming Ellipses
   for BAPC2016
   author: Peter Kluit
   date  : July 2014
 */

import java.util.*;

public class HammingEllipsesPGK{

   public static void main (String [] args){
      Scanner ir = new Scanner(System.in);
      int q = ir.nextInt();
      int n = ir.nextInt();
      int d = ir.nextInt();
      String f1 = ir.next();
      String f2 = ir.next();
      HammingEllipsesPGK solver = new HammingEllipsesPGK(q, n, d, f1, f2);
      System.out.println(solver.solve());
   }

///////////////////////////////////////////////////////
   int q;
   int n;
   int d;
   int focalDist;

   public HammingEllipsesPGK(int qIn, int nIn, int dIn, String f1, String f2){
      q = qIn;
      n = nIn;
      d = dIn;
      focalDist = distance(f1, f2);
   }

   private long solve(){
      long result = 0;
      int equal = n - focalDist;  // no of equals of f1 and f2
      if (d < focalDist)
         return 0;

      for (int d1 = d - n; d1 <= n ; d1++){
         int d2 = d - d1;
         int eq1 = n - d1;
         int eq2 = n - d2;
         for (int k = 0; k <= equal && k <= eq1 && k <= eq2; k++){
            int eqq1 = eq1 - k;
            int eqq2 = eq2 - k;
            int nn   = n - equal;
            long term = pow(q-1, equal - k);
            term = term * binom(equal, k);
            term = term * trinom(nn, eqq1, eqq2);
            term = term * pow(q - 2, nn - eqq1 - eqq2);
            result += term;
         }
      }
      return result;
   }

   int distance(String f1, String f2){
      int dist = 0;
      for (int k = 0; k < f1.length(); k++)
         if (f1.charAt(k) != f2.charAt(k))
             dist++;
      return dist;
   }

   public long pow(long x, long n){
      long r = 1;
      while (n > 0){
         if (n % 2 == 1)
            r *=  x;
         n /= 2;
         x *=  x;
      }
      return r;
   }

   public long trinom(int n, int k1, int k2){
      return binom(n, k1) * binom(n - k1, k2);
   }

   public long binom(int n, int k){
      if (k > n)
         return 0;
      if (2 * k > n)
         k = n - k;
      int [] factors = new int[k];
      for (int t = 0; t < k; t++)
         factors[t] = n - t;
      for (int t = 2; t <= k; t++){
         int tt = t;
         for (int w = 0; tt > 1; w++){
            int g = ggd(tt, factors[w]);
            tt /= g;
            factors[w] /= g;
         }
      }
      long result = 1;
      for (int t = 0; t < k; t++)
         result *= factors[t];
      return result;
   }

    private static int ggd(int g, int k){
		while (k != 0){
		    int r = g % k;
		    g = k;
		    k = r;
		}
		return g;
	}

}