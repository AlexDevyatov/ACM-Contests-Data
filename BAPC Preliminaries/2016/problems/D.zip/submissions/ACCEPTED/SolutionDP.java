import java.util.*;
import java.io.*;

/***
  * dynamic programming implementation
***/
public class SolutionDP {
	int[] X;
	int[] Y;
	int n;
	int D;
	int q;
//    static int M = 1000000007;
	 
	public static void main(String[] args) {
		try{
	          InputStream input = System.in;
	          Scanner sc = new Scanner(input);
        	  SolutionDP sol = new SolutionDP();
	          sol.q = sc.nextInt();
	          sol.n = sc.nextInt();
	          sol.D = sc.nextInt();
	          sol.X = new int[sol.n];
	          sol.Y = new int[sol.n];
	          sc.nextLine();
	          byte[] sX = sc.nextLine().getBytes();
	          for( int i = 0; i < sol.n; ++i )
	        	  sol.X[i] = Character.getNumericValue(sX[i]);
	          byte[] sY = sc.nextLine().getBytes();
	          for( int i = 0; i < sol.n; ++i )
	        	  sol.Y[i] = Character.getNumericValue(sY[i]);
	          input.close();
	          sc.close();
		      System.out.println(sol.solve());
	      }
	      catch (IOException iox){System.out.println(iox);}		
	}
	
	public long solve()
	{
		long count[] = new long[D+1];
		// for n there is 1 possibility
		count[0] = 1;
		for(int i=n-1; i >= 0; --i)
		{
//		    System.out.println("iteration "+i);
		    for(int d=D; d >= 0; --d)
			{
				long counter = 0;
				if( X[i] == Y[i] ) {
					if( d >=2 )
						counter = counter + (q-1) * count[d-2];
//						counter = (counter + ((q-1) * count[d-2]) % M) % M;
//					counter = (counter + count[d]) % M;
					counter = counter + count[d];
				} else {
					if( d >= 1 )
						counter = counter + 2 * count[d-1];
//						counter = (counter + (2 * count[d-1]) % M) % M;
					if( d >= 2)
						counter = counter + (q-2) * count[d-2];
//						counter = (counter + ((q-2) * count[d-2]) % M) % M;
				}
				count[d] = counter;
			}
		}
		return count[D];
	}
}
