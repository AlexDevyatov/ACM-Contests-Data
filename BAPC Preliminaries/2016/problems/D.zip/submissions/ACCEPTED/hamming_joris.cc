/*
 * Solution to Hamming Ellipses
 *
 * Algorithm: Use binomial coefficients to calculate the number of
 * points that match all criteria.
 *
 * This program can only produce answers up to 2**63 - 1.
 *
 * Time complexity O(n**2 * log(n)).
 */

// @EXPECTED_RESULTS@: CORRECT

#include <stdio.h>
#include <assert.h>
#include <limits.h>
#include <vector>

using namespace std;


static constexpr int MIN_Q = 2;
static constexpr int MAX_Q = 10;
static constexpr int MAX_N = 100;
static constexpr int MIN_D = 1;


typedef long long NumberType;
#define OUTPUT_FORMAT "%lld"
static constexpr long long MAX_TMP = LLONG_MAX;


int gcd(int p, int q)
{
    assert(p > 0);
    assert(q > 0);
    while (q > 0) {
        int t = p % q;
        p = q;
        q = t;
    }
    return p;
}   


/* Calculate binomial coefficient. */
NumberType binom(int n, int k)
{
    NumberType b = 1;
    for (int i = 1; i <= k; i++) {
        // Compute b' = b * (i + n - k) / i
        // Avoid intermediate values higher than the final answer.
        int p = i + n - k;
        int q = i;
        int g = gcd(p, q);
        p /= g;
        q /= g;
        assert(b % q == 0);
        b /= q;
        assert(b <= MAX_TMP / p);
        b *= p;
    }
    return b;
}


/* Calculate hamming distance between words f1 and f2. */
int hamming_distance(const vector<int>& f1, const vector<int>& f2)
{
    assert(f1.size() == f2.size());
    int d = 0;
    for (int i = 0, n = f1.size(); i < n; i++) {
        if (f1[i] != f2[i]) {
            d++;
        }
    }
    return d;
}


/* Solve the problem. */
NumberType solve(int q, int n, int d,
                 const vector<int>& f1, const vector<int>& f2)
{
    int fdist = hamming_distance(f1, f2);

    if (q == 1) {
        // Special case: the entire space contains only 1 point.
        return (d == 0) ? 1 : 0;
    }

    /*
     * Define V = set of (n-fdist) positions where f1 and f2 are the same.
     * Define W = set of (fdist) positions where f1 and f2 are different.
     *
     * For each k, 0 <= k <= fdist:
     *
     *   Count the number of words with the following properties:
     *     different from f1 and from f2 in k positions from W;
     *     different from either f1 or f2 in (fdist-k) positions from W;
     *     different from f1 and from f2 in (D-fdist-k)/2 positions from V.
     *
     *   Each of these has sum of difference to f1 and f2 equal to D.
     *   If fdist + k > D, no such words exist.
     *   Otherwse if D - fdist - k is odd, no such words exist.
     *   Otherwise if (D-dist-k)/2 > n-fdist, no such words exist.
     *   Otherwise, the number of these words is equal to
     *      (q-2)**k * 2**(fdist-k) * Binomial(fdist, k) *
     *      (q-1)**((D-fdist-k)/2) * Binomial(n-fdist, (D-fdist-k)/2)
     *
     *   NOTE: q == 2 is somewhat special: there are no words different from
     *         both f1 and f2 on any positions in W.
     */

    NumberType ans = 0;

    for (int k = 0; k <= fdist; k++) {

        if (q == 2 && k > 0) {
            // Impossible to differ from f1 and from f2 in positions
            // where f1 and f2 are already different.
            continue;
        }

        int u = d - fdist - k;
        if (u < 0 || u % 2 != 0 || u/2 > n - fdist) {
            // There are no words that meet all criteria.
            continue;
        }

        // Must be different from f1 and f2 in p out of (n-fdist) positions
        // from V.
        int p = u / 2;

        // Select k out of fdist positions.
        NumberType a = binom(fdist, k);

        // Choose between f1 and f2 in (fdist-k) positions.
        // Multiply by 2**(fdist-k).
        for (int i = 0; i < fdist-k; i++) {
            assert(a <= MAX_TMP / 2);
            a *= 2;
        }

        // Choose symbols different from both f1 and f2 in k positions.
        // Multiply by (q-2)**k.
        for (int i = 0; i < k; i++) {
            assert(a <= MAX_TMP / (q-2));
            a *= (q-2);
        }

        // Select p out of (n-fdist) positions.
        NumberType t = binom(n-fdist, p);
        assert(a <= MAX_TMP / t);
        a *= t;

        // Choose symbols different from f1 (and thus from f2) in p positions.
        // Multiply by (q-1)**p.
        for (int i = 0; i < p; i++) {
            assert(a <= MAX_TMP / (q-1));
            a *= (q-1);
        }

        // Add to final answer.
        assert(ans <= MAX_TMP - a);
        ans += a;
    }

    return ans;
}


/* Main program. */
int main(void)
{
    // Read input.
    int q = -1, n = -1, d = -1;
    scanf("%d %d %d", &q, &n, &d);
    assert(q >= MIN_Q && q <= MAX_Q);
    assert(n >= 1 && n <= MAX_N);
    assert(d >= MIN_D && d <= 2*n);

    vector<int> f1(n);
    vector<int> f2(n);

    for (vector<int> *v : { &f1, &f2 }) {
        scanf(" ");
        for (int i = 0; i < n; i++) {
            int c;
            c = fgetc(stdin);
            assert(c >= '0' && c <= '9');
            c -= '0';
            assert(c >= 0 && c < q);
            v->at(i) = c;
        }
    }

    // Solve problem.
    NumberType ans = solve(q, n, d, f1, f2);

    // Write output.
    printf(OUTPUT_FORMAT "\n", ans);

    return 0;
}

// end
