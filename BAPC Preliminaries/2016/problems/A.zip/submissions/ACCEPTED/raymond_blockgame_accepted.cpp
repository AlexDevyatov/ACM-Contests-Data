#include <iostream>
#include <cassert>

using namespace std;

bool canplayeronewin(long long n, long long m) {
	if (m == 0)	// The previous player just won.
		return false;	
	if (n >= 2*m)		// It does not matter whether (m, n - floor(n/m)*m) is winning or not.
		return true;	// Player one can either go to that state directly or force player two to do it.
	return not(canplayeronewin(m, n-m));	// There is no other choice for player one.
}

int main () {
	long long m, n;
	cin >> n >> m;
	assert(1 <= m);
	assert(1 <= n);	// Input checker
	assert(n <= 1000000000000000000LL);
	assert(m <= 1000000000000000000LL);
	if (m > n) {
		long long temp = n;
		n = m;
		m = temp;
	}
	if (canplayeronewin(n,m))
		cout << "win\n";
	else
		cout << "lose\n";
	return 0;
}

