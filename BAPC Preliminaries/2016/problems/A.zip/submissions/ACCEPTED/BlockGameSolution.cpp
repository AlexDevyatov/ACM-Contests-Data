#include <iostream>

using namespace std;
typedef unsigned long long ull;

int main() {
  // Read the input, make sure that a contains the smaller number.
  ull a,b,tmp;
  cin >> a >> b;
  if(b < a) {
    tmp = a;
    a = b;
    b = tmp;
  }

  bool win = true;

  // Simulate the game until a guaranteed winning position is reached.
  while(true) {
    if(b % a == 0 || b / a >= 2)
      // As soon as you can either win the game directly or have more than
      // one choice, you win the game.
      break;
    else {
      // If you have only one choice, we continue the simulation with the
      // other player.
      win = !win;
      tmp = a;
      a = b % a;
      b = tmp;
    }
  }

  if(win)
    cout << "win" << endl;
  else
    cout << "lose" << endl;
  return 0;
}

