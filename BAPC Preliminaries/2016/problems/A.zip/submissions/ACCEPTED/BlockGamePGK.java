/*
   Solution for Block Game
   a problem for BAPC 2016
   August 2016
   author: Peter Kluit
 */

import java.util.*;
public class BlockGamePGK{
   public static void main (String [] args){
      Scanner st = new Scanner(System.in);
      long n = st.nextLong();
      long m = st.nextLong();
      System.out.println(solve(m,n));
   }

   private static String solve(long a, long b){
      if (a == b)
         return "win";
      if (a < b){
         long help = a;
         a = b;
         b = help;
      }
      //a > b
      boolean myTurn = true;
      while (2 * b > a){
          long help = b;
          b = a - b;
          a = help;
          // a > b
          myTurn = !myTurn;
      }
      if (myTurn)
         return "win";
      else
         return "lose";
   }
}