#include <iostream>
#include <cassert>

using namespace std;

bool canplayeronewin(long long n, long long m) {
	if (m > n) {	// If necessary, swap to make sure that m <= n.
		long long temp = n;
		n = m;
		m = temp;
	}
	if ((n%m) == 0)	// You can win next turn.
		return true;	
	for (int i = 1; i*m <= n; i++)
		if (not(canplayeronewin(n - i*m, m)))
			return true;
	return false;
}

int main () {
	long long m, n;
	cin >> n >> m;
	if (canplayeronewin(n,m))
		cout << "win\n";
	else
		cout << "lose\n";
	return 0;
}

