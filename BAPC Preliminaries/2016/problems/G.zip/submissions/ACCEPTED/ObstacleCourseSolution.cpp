#include <iostream>
#include <queue>

using namespace std;

typedef pair<int,pair<int,int> > trip;

int course[1000][1000];
bool visited[1000][1000];

int main() {
  // Read input into course, set visited to false.
  int m,n;
  cin >> m >> n;

  for(int i = 0; i < m; i++) {
    for(int j = 0; j < n; j++) {
      cin >> course[i][j];
      visited[i][j] = false;
    }
  }

  // The position at the front of the queue is the next position that
  // is easiest to reach.
  priority_queue<trip,vector<trip>,greater<trip> > q;
  q.push(make_pair(0,make_pair(0,0)));
  int ladder = 0;
  while(true) {
    trip t = q.top(); q.pop();
    ladder = max(ladder, t.first);
    int i = t.second.first;
    int j = t.second.second;

    // If we reach our destination, we are done; ladder contains the
    // answer.
    if(i == m - 1 && j == n - 1)
      break;

    // If we have visited the position before, continue.
    if(visited[i][j])
      continue;
    visited[i][j] = true;

    // Add all neighbours of the current position as visited.
    for(int x = -1; x <= 1; x++) {
      for(int y = -1; y <= 1; y++) {
        if((x == 0) == (y == 0))
          continue;
        if(i + x < 0 || i + x >= m || j + y < 0 || j + y >= n)
          continue;
        q.push(make_pair(course[i+x][j+y]-course[i][j],
                make_pair(i+x,j+y)));
      }
    }
  }
  cout << ladder << endl;
  return 0;
}
