import java.util.*;
import java.io.*;

/**
 * @author mathijs
 * p019 ObstacleCourse
 * with variant of Dijkstra, replacing min distance with min ladder
 * O( mn log mn )
 */
public class Solution {
	
	public static void main(String[] args) {
		try{
	          InputStream input = System.in;
	          Scanner sc = new Scanner(input);
//	          int cases = sc.nextInt();
//	          for( int i = 1; i <= cases ; ++i)
//	          {
	        	  int m = sc.nextInt();
	        	  int n = sc.nextInt();
	        	  int locations[][][] = new int[m][n][2];
	        	  for( int x = 0; x < m; ++x )
	        		  for( int y = 0; y < n; ++y)
	        		  {
	        			  locations[x][y][0] = sc.nextInt();
	        			  locations[x][y][1] = 0;
	        		  }
	        	  Solution sol = new Solution();
		          System.out.println(sol.solveDijkstra(m, n, locations));
//	          }
	          input.close();
	          sc.close();
	      }
	      catch (IOException iox){System.out.println(iox);}
	}

	public Solution(){
	}
	
	public int solveDijkstra( int m, int n, int[][][] locations )
	{
		PriorityQueue<State> Q = new PriorityQueue<State>();
		// contains ladder required, and position
		State s = new State( 0, 0, 0);
		Q.add(s);
		while(! Q.isEmpty())
		{
			s = Q.remove();
			if( s.x == m-1 && s.y == n-1 )
				return s.ladder;
			locations[s.x][s.y][1]=1;
			for( int x = Math.max(0, s.x-1); x <= Math.min(m-1, s.x+1); x += 1){
				for( int y = Math.max(0, s.y-1); y <= Math.min(n-1, s.y+1); y += 1){
					if( Math.abs(x-s.x) + Math.abs(y-s.y) == 1 )
					{
						int ladder = Math.max(s.ladder, locations[x][y][0]-locations[s.x][s.y][0]); 
						if( locations[x][y][1] == 0 )
						{
							State nb = new State( x, y, ladder );
							Q.add(nb);
						}
					}
				}
			}
		}
		return -1;
	}
	
	protected class State implements Comparable<State> {
		int ladder;
		int x;
		int y;
	
		public State( int x, int y, int ladder )
		{
			this.x = x;
			this.y = y;
			this.ladder = ladder;
		}
		
		@Override
		public int compareTo( State other )
		{
			return this.ladder - other.ladder;
		}
	
	}	
}
