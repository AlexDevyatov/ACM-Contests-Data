#include <iostream>
#include <queue>

using namespace std;

typedef pair<int,int> pi;

int course[1000][1000];
bool visited[1000][1000];

int main() {
  // Read input into course, set visited to false.
  int m,n;
  cin >> m >> n;
  // lo definitely will not work, hi definitely will.
  int lo = -1, hi = 0; 
  for(int i = 0; i < m; i++) {
    for(int j = 0; j < n; j++) {
      cin >> course[i][j];
      hi = max(hi, course[i][j]);
      visited[i][j] = false;
    }
  }

  while(hi - lo > 1) {
    int mid = (hi + lo)/2;
    queue<pi> q;
    q.push(make_pair(0,0));
    while(!q.empty()) {
      pi p = q.front(); q.pop();
      int i = p.first;
      int j = p.second;

      // If we reach our destination, we are done; mid is sufficient.
      if(i == m - 1 && j == n - 1) {
        hi = mid;
        break;
      }

      // If we have visited the position before, continue.
      if(visited[i][j])
        continue;
      visited[i][j] = true;

      // Add all reachable neighbours of the current node to the queue.
      for(int x = -1; x <= 1; x++) {
        for(int y = -1; y <= 1; y++) {
          if((x == 0) == (y == 0))
            continue;
          if(i + x < 0 || i + x >= m || j + y < 0 || j + y >= n)
            continue;
          if(course[i+x][j+y]-course[i][j] <= mid) {
            q.push(make_pair(i+x,j+y));
          }
        }
      }
    }
    // If we did not set hi to mid, then mid is not sufficient. So we set
    // lo = mid.
    if(hi != mid) {
      lo = mid;
    }

    // Reset visited.
    for(int i = 0; i < m; i++) {
      for(int j = 0; j < n; j++) {
        visited[i][j] = false;
      }
    }
  }
  cout << hi << endl;
  return 0;
}
