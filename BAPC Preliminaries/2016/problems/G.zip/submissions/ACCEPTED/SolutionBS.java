import java.util.*;
import java.io.*;

/**
 * @author mathijs
 * p019 ObstacleCourse
 * with binary search and BFS: pseudopolymial because O(mn log maxladder)
 */
public class SolutionBS {
	
	public static void main(String[] args) {
		try{
	          InputStream input = System.in;
	          Scanner sc = new Scanner(input);
//	          int cases = sc.nextInt();
//	          for( int i = 1; i <= cases ; ++i)
//	          {
	        	  int m = sc.nextInt();
	        	  int n = sc.nextInt();
	        	  int locations[][][] = new int[m][n][2];
	        	  for( int x = 0; x < m; ++x )
	        		  for( int y = 0; y < n; ++y)
	        		  {
	        			  locations[x][y][0] = sc.nextInt();
	        			  locations[x][y][1] = 0;
	        		  }
	        	  SolutionBS sol = new SolutionBS();
		          System.out.println(sol.solveBinarySearch(m, n, locations));
//	          }
	          input.close();
	          sc.close();
	      }
	      catch (IOException iox){System.out.println(iox);}
	}

	public SolutionBS(){
	}
		
	public int solveBinarySearch( int m, int n, int[][][] locations )
	{
		int maxladder = 0;
		for( int x = 0; x < m; ++x )
			for( int y = 0; y < n; ++y)
			{
				if( x < m-1 )
					maxladder = Math.max(maxladder, Math.abs(locations[x][y][0]-locations[x+1][y][0]));
				if( y < n-1 )
					maxladder = Math.max(maxladder, Math.abs(locations[x][y][0]-locations[x][y+1][0]));
			}
		int lb = 0;
		int ub = maxladder;
		// ub: always yes
		while( ub-lb > 0 )
		{
			int ladder = (lb+ub)/2; // round down
			for( int x = 0; x < m; ++x )
				for( int y = 0; y < n; ++y)
					locations[x][y][1] = 0;
			if( BFS(m, n, locations, ladder) )
				ub = ladder;
			else
				lb = ladder+1;				
		}
		return ub;
	}
	
	protected boolean BFS(int m, int n, int[][][] locations, int ladder)
	{
		LinkedList<State> Q = new LinkedList<State>();
		State s = new State( 0, 0);
		locations[0][0][1]=1;
		Q.add(s);
		while(! Q.isEmpty())
		{
			s = Q.remove();
			if( s.x == m-1 && s.y == n-1 )
				return true;
			for( int x = Math.max(0, s.x-1); x <= Math.min(m-1, s.x+1); x += 1){
				for( int y = Math.max(0, s.y-1); y <= Math.min(n-1, s.y+1); y += 1){
					if( Math.abs(x-s.x) + Math.abs(y-s.y) == 1 )
					{
						if( locations[x][y][1] == 0 &&
								 locations[x][y][0]-locations[s.x][s.y][0] <= ladder) 
						{
							State nb = new State( x, y );
							locations[x][y][1]=1;
							Q.add(nb);
						}
					}
				}
			}
		}
		return false;
	}

	protected class State {
		int x;
		int y;
	
		public State( int x, int y )
		{
			this.x = x;
			this.y = y;
		}
	
	}	
}
