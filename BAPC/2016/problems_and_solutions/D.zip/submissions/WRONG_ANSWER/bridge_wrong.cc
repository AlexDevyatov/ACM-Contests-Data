/*
 * Incorrect solution for Bridge Automation
 */

// @EXPECTED_RESULTS@: WRONG-ANSWER

#include <stdio.h>
#include <assert.h>
#include <algorithm>
#include <vector>

using namespace std;


/* Solve the probblem (but not really). */
int solve(const vector<int>& boats)
{
    int cost = 0;
    int openbridge = 0;
    int closebridge = 0;

    // Consider all boats.
    for (int b : boats) {

        if (openbridge > 0) {

            // Bridge will open at firstboat + 1800.
            if (closebridge + 90 < b) {

                // Boat is too late.
                // Open the bridge and let everyone else through.
                cost += 60 + (closebridge - openbridge) + 60;
                openbridge = b + 1800;
                closebridge = openbridge + 20;

            } else {

                // Boat will wait in line with others.
                closebridge = max(closebridge, b) + 20;

            }

        } else {

            // First boat to wait for closed bridge.
            openbridge = b + 1800;
            closebridge = openbridge + 20;

        }

    }

    // Open the bridge and let last bunch of boats through.
    if (openbridge > 0) {
        cost += 60 + (closebridge - openbridge) + 60;
    }

    return cost;            
}


/* Main program. */
int main(void)
{
    // Read input.
    int nboat;
    scanf("%d", &nboat);
    assert(nboat >= 1 && nboat <= 4000);

    vector<int> boats;

    for (int i = 0; i < nboat; i++) {
        int t;
        int r = scanf("%d", &t);
        assert(r == 1);
        assert(t >= 60 && t <= 100000);
        assert(boats.size() == 0 || boats[i-1] + 20 <= t);
        boats.push_back(t);
    }

    // Solve problem.
    int ans = solve(boats);

    // Write output.
    printf("%d\n", ans);

    return 0;
}

// end
