#include <iostream>
#include <vector> 
#include <cassert>
using namespace std;

// Same idea as correct solution; however, here we calculate the optimal strategy for all intervals instead of prefices (i.e. 1..i). 
// This results in a runtime of O(n^3).

int main()
{
	int n;
	cin >> n;
	vector<int> boats(n);
	for(int i = 0; i < n; ++i)
	{
		cin >> boats[i];
		if(i != 0) assert(boats[i] >= boats[i-1] + 20);
		assert(boats[i] >= 60 && boats[i] <= 100000);
	}
	
	vector<vector<int>> dp(n, vector<int>(n));
	vector<vector<int>> dp2(n, vector<int>(n));
	
	for(int s = 0; s < n; ++s) // Size of interval - 1.
		for(int i = 0; i < n - s; ++i) // Start of interval.
		{	
			int j = i + s;
			int low = 120 + max(20*(j - i + 1), (boats[j] + 20) - (boats[i] + 1800)); // We let all boats pass at once.
			for(int k = i; k < j; ++k)
				low = min(low, dp[i][k] + dp2[j][k + 1]); // If the boats do not pass at once, there is a "break" somewhere.
			dp[i][j] = low;
			dp2[j][i] = low;
		}
	cout << dp[0][n-1] << "\n";	
	return 0;
}




