/*
   Wrong Solution for MultiplyDigits
   a problem for DAPC/BAPC 2016
   June 2016

 */


import java.util.*;

public class FailMultiplyDigits{
     public static void main (String []args){
        Scanner st = new Scanner(System.in);
        int base = st.nextInt();
        long n = st.nextLong();
        FailMultiplyDigits solver = new FailMultiplyDigits(base);
        System.out.println(solver.solve(n));
     }

////////////////////////////////////////////////////////

   int BASE;

   public FailMultiplyDigits(int base){
      BASE = base;
   }

   public String solve (long n){
      if (impossible(n))
         return "impossible";
      else{
         return "" +  leastInv(n);
      }
   }
   
   private long leastInv(long n){
       if (n < BASE)
          return n;
       for (int digit = BASE - 1; digit > 1; digit --)
          if (n % digit == 0){
             long rest = leastInv(n/digit);
             return BASE * rest + digit;
          }
       return -1;
    }

    private boolean impossible(long n){
       for (int d = 2; d < BASE ; d++)
          while (n % d == 0)
             n /= d;
       return n > 1;
    }
}