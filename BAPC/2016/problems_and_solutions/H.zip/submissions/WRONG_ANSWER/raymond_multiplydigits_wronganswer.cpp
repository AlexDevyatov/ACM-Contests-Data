#include <iostream>
#include <cassert>

using namespace std;

long long b;
bool first = true;

int nrofdigitsneeded (long long n) {	// How many digits are needed to get n?
	int ret = 0;
	for (int i = b-1; i >= 2; i--)
		while ((n % i) == 0) {
			if (first)
				cerr << "Using digit " << i << "\n";
			n /= i;
			ret += 1;
		}
	if (n == 1)
		return ret;
	return 123456789;
}

int main () {
	long long n;
	cin >> b >> n;
	first = true;
	int needed = nrofdigitsneeded(n);
	first = false;
	cerr << needed << '\n';
	if (needed == 123456789) {
		cout << "impossible\n";
		return 0;
	}
	long long sol = 0;
	for (int i = 2; i < b; i++)	// Try digits, starting from the smallest, seeing whether or not we can use it.
		while (((n % i) == 0) && (nrofdigitsneeded(n/i) == needed-1)) {
			n /= i;
			needed--;
			sol *= b;
			sol += i;
		}
	assert(needed == 0);
	cout << sol << "\n";
	return 0;
}



