// @EXPECTED_RESULTS@: TIMELIMIT,WRONG-ANSWER
#include <iostream>
#include <cassert>
#include <climits>

using namespace std;

unsigned long long b;
const unsigned long long INFINITY = ULLONG_MAX-1;
int maxdepth = -1;

bool possible (unsigned long long n) {
	for (int i = b-1; i >= 2; i--)
		while ((n % i) == 0) {
			n /= i;
			maxdepth++;
		}
	return (n == 1);
}

unsigned long long sol (unsigned long long n, unsigned long long maxdigit, int depth) {
	unsigned long long maxpossible = 1;
	for (int i = depth; i <= maxdepth; i++) {
		for (unsigned long long j = 2; j <= maxdigit; j++) {
			if (maxpossible*j > INFINITY/2) {
				maxpossible = INFINITY;
			}
		}
		if (maxpossible == INFINITY)
			break;
		maxpossible *= maxdigit;
	}
	if (n < b) {
		maxdepth = depth;
		return n;	
	}
	if ((depth > maxdepth) || (maxpossible < n))
		return INFINITY/b - b;	
	unsigned long long ret = INFINITY;
	for (unsigned long long i = maxdigit; i*i >= b; i--)
		if ((n % i) == 0) {
			bool gofurther = false;
			for (unsigned long long j = 2; j*i < b; j++)
				if ((n % (i*j) == 0) && (j*i < b))
					gofurther = true;
			if (gofurther)
				continue;
			unsigned long long num = sol(n/i, i, depth+1);
			for (unsigned long long j = 1; j <= 2*b; j *= 2)
				if (j*num > INFINITY/2) {
					num = INFINITY/b - b;
					break;
				}
			unsigned long long poging = b*num + i;
			ret = min(ret, poging);				
		}	
	if (ret < INFINITY/2 + 2) 
		return ret;	
	else
		return INFINITY/b - b;
}

int main () {
	unsigned long long n;
	cin >> b >> n;
	if (!possible(n)) {
		cout << "impossible\n";
		return 0;
	}
	cout << sol(n,b-1,0) << "\n";
	return 0;
}



