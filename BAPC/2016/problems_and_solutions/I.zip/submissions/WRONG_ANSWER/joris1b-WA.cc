/*
 * Clumsy solution to Older Brother.
 * Slight variation on joris1.cc: we reverse the order of the no and yes labels.
 * This is a problem if q is prime.
 * 
 * Author: Josse (not Joris!)
 */

#include <stdio.h>
#include <assert.h>

using namespace std;


int main(void)
{
    int q = -1;
    scanf("%d", &q);
    assert(q >= 1 && q <= 1000000000);

    if (q == 1) {
        goto no;
    }

    for (int p = 2; p * p <= q; p++) {
        if (q % p == 0) {
            for (int k = 1; ; k++) {
                int t = 1;
                for (int i = 0; i < k; i++) {
                    t *= p;
                }
                if (t == q) {
                    goto yes;
                }
                if (t > q / p) {
                    goto no;
                }
            }
        }
    }

no:
    fputs("NO\n", stdout);
    return 0;

yes:
    fputs("YES\n", stdout);
    return 0;
}

// end
