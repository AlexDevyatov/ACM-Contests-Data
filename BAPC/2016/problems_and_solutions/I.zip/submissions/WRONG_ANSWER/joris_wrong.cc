/*
 * Incorrect solution to Older Brother.
 *
 * This program will only print YES if q = p**(2**k).
 */

#include <stdio.h>
#include <assert.h>

using namespace std;


int main(void)
{
    int q = -1;
    scanf("%d", &q);
    assert(q >= 1 && q <= 1000000000);

    bool ans = (q > 1);

    for (int p = 2; p * p <= q; p++) {
        if (q % p == 0) {
            while (p <= q / p) {
                p = p * p;
            }
            if (p == q) {
                ans = true;
            } else {
                ans = false;
            }
            break;
        }
    }

    fputs(ans ? "YES\n" : "NO\n", stdout);
    return 0;
}

// end
