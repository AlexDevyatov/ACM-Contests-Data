// Try a bunch of high-order roots of q and check if prime.
// 
// This is a variation on 2-try-roots-AC.cpp. We use floats, so we get rounding
// errors. This program generally fails on large inputs, though it does solve
// some of them correctly.

#include <iostream>
#include <cmath>
#include <cassert>

using namespace std;

const long long MIN_Q = 1;
const long long MAX_Q = 1000000000; // 10^9

const float epsilon = 1e-5L;

bool isprime(long long p) {
	if (p <= 1) return false;
	for (long long q = 2; q * q <= p; q++) {
		if (p % q == 0) return false;
	}
	return true;
}

int main() {
	long long q;
	cin >> q;
	assert(q >= MIN_Q && q <= MAX_Q);
	for (float k = 1; k < 100; k += 1.0L) {
		float candidate = pow((float) q, 1.0L / k);
		if (abs(candidate - round(candidate)) > epsilon) continue;
		long long p = llround(candidate);
		float reconstruction = pow((float) p, k);
		if (abs(reconstruction - q) > epsilon) continue;
		if (isprime(p)) {
			cout << "YES" << endl;
			return 0;
		}
	}
	cout << "NO" << endl;
	return 0;
}
