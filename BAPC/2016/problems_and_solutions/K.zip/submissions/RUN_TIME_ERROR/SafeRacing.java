/*
  Solution in Java for Safe Racing
  a problem for BAPC2016
  author: Peter Kluit
  September 2016

*/

import java.util.*;
public class SafeRacing{

   final static long MOD = 123456789;

   public static void main (String [] args){
      Scanner ir = new Scanner(System.in);
      int l = ir.nextInt();
      int  s = ir.nextInt();
      long w = solve(l, s);
      System.out.println(w);
   }
   
   static long [][] series;

   private static long solve (int l, int s){
       series = new long [l+1][];
       series[1] = new long[1];
       series[1][0] = 1;
       long sum = 1;
       for (int k = 2; k <= l; k++){
          series[k] = new long[k];
          series[k][0]= sum;

          for (int z = 1; z < k && z < s; z++){
             series[k][z] = series[k-1][z-1];
             sum += series[k][z];
          }
          sum = sum % MOD;
       }

       long answer = 0;
       for (int sh = 0; sh < s; sh++){
          for (int z = 0; z + sh < s; z++)
             answer += series[l-sh][z];
          answer = answer % MOD;
       }
       return answer;
   }
      
}