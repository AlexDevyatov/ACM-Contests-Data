// @EXPECTED_RESULTS@: TIMELIMIT,RUN-ERROR
// Time limit to: Safe racing
// By: Raymond van Bommel

#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cctype>
#include <climits>
#include <cassert>

#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <list>
#include <set>
#include <map>
#include <string>

#include <iostream>
#include <sstream>

#include <utility>
#include <functional>
#include <limits>
#include <numeric>
#include <algorithm> 

using namespace std;

int L, S;

const long long Modulus = 123456789;

long long dp[2502][2502]; // dp[d][l] = number of ways to put marshalls on the first d decametres such that the last marshall is at d-l

void DP() {
	for (int d = 1; d <= L; d++) {
		for (int l = 0; l < S; l++) {
			if (l > 0)	
				dp[d][l] = dp[d-1][l-1];	// Not putting a marshall at d
			dp[d][0] += dp[d-1][l];	// Putting a marshall at d
			dp[d][0] %= Modulus;
		}
	}
}

void doit() {
	cin >> L >> S;
	long long ans = 0;
	for (int f = 1; f <= S; f++) { // Put the first marshall after the start on f;
		for (int d = 0; d <= L; d++)
		for (int l = 0; l < S; l++)
			dp[d][l] = 0;		// Initialise DP table
		dp[f][0] = 1;
		DP();	// Execute DP
		for (int l = 0; l+f <= S; l++) {
			ans += dp[L][l];
			ans %= Modulus;
		}
	}
	cout << ans << '\n';
}

int main () {
	int T = 1;
	//cin >> T;
	for (int t = 1; t <= T; t++) {
		doit();
	}
	return 0;
}
