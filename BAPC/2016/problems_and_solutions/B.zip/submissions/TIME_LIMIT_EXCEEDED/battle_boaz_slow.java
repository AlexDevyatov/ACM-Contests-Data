import java.io.*;
import java.util.*;

public class battle_boaz_slow {
	static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	public battle_boaz_slow() {}

	public static void main(String[] args) throws Exception {
		new battle_boaz_slow().doProblem();
	}

	public static void out(Object o, boolean newline) {
		if (newline) System.out.println(o.toString());
		else System.out.print(o.toString());
		System.out.flush();
	}

	public static void out(Object o) {
		out(o, true);
	}

	public void doProblem() throws Exception {
		out(solve());
	}

	public String solve() throws Exception {
        int ignore = 0;
        char[] moves = new char[3];
        String result = "";

        for (int i = 0; i < 3; i++)
            moves[i] = (char)in.read();

        while (moves[0] != '\n' && moves[0] != '\0') {
            if (ignore > 0)
                --ignore;
            else {
                if (moves[0] == 'R') { 
                    if ((moves[1] == 'B' && moves[2] == 'L') || (moves[1] == 'L' && moves[2] == 'B')) {
                        result += "C";
                        ignore = 2;
                    }
                    else result += "S";
                } 
                if (moves[0] == 'B') { 
                    if ((moves[1] == 'R' && moves[2] == 'L') || (moves[1] == 'L' && moves[2] == 'R')) { 
                        result += "C";
                        ignore = 2;
                    }
                    else result += "K";
                }
                if (moves[0] == 'L') { 
                    if ((moves[1] == 'B' && moves[2] == 'R') || (moves[1] == 'R' && moves[2] == 'B')) {
                        result += "C";
                        ignore = 2;
                    }
                    else result += "H";
                }
            }
            char input = (char)in.read();

            moves[0] = moves[1];
            moves[1] = moves[2];
            moves[2] = input;
        }
        return result;
	}
}
