/*
 * Incorrect solution to Manhattan Positioning System
 *
 * This program tests all points in a rectangular region.
 * It should we way too slow.
 */

// @EXPECTED_RESULTS@: TIMELIMIT

#include <stdio.h>
#include <assert.h>
#include <limits.h>
#include <algorithm>
#include <vector>

using namespace std;

struct Beacon { int x, y, d; };

int main(void)
{
    int nbeacon;
    scanf("%d", &nbeacon);
    assert(nbeacon >= 1);

    vector<Beacon> beacons;

    int minx = INT_MIN, miny = INT_MIN;
    int maxx = INT_MAX, maxy = INT_MAX;

    for (int i = 0; i < nbeacon; i++) {
        Beacon b;
        scanf("%d %d %d", &b.x, &b.y, &b.d);
        assert(b.d >= 0);
        beacons.push_back(b);
        minx = max(minx, b.x - b.d);
        miny = max(miny, b.y - b.d);
        maxx = min(maxx, b.x + b.d);
        maxy = min(maxy, b.y + b.d);
    }

    int recvx, recvy;
    bool have_solution = false;

    for (int x = minx; x <= maxx; x++) {
        for (int y = miny; y <= maxy; y++) {
            bool ok = true;
            for (const auto& b : beacons) {
                if (abs(b.x - x) + abs(b.y - y) != b.d) {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                if (have_solution) {
                    printf("uncertain\n");
                    return 0;
                }
                recvx = x;
                recvy = y;
                have_solution = true;
            }
        }
    }

    if (have_solution) {
        printf("%d %d\n", recvx, recvy);
    } else {
        printf("impossible\n");
    }

    return 0;
}

// end
