// TLE to: MPS
// By: Raymond van Bommel

#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cctype>
#include <climits>
#include <cassert>

#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <list>
#include <set>
#include <map>
#include <string>

#include <iostream>
#include <sstream>

#include <utility>
#include <functional>
#include <limits>
#include <numeric>
#include <algorithm> 

using namespace std;

int N;
int X[1001], Y[1001], D[1001];

int d(int x1, int y1, int x2, int y2) {
	return (abs(x1-x2) + abs(y1-y2));
}

bool checkpoint (int x, int y) {
	for (int i = 0; i < N; i++)
		if (d(x,y,X[i],Y[i]) != D[i])
			return false;
	return true;
}

int main () {
	cin >> N;
	for (int i = 0; i < N; i++)
		cin >> X[i] >> Y[i] >> D[i];
	//cerr << "Read\n";
	int nrofsol = 0;
	int solx, soly;
	for (int i = -D[0]; i <= D[0]; i++) {
		//cerr << "i = " << i << "\n";
		for (int j = -1; j <= 1; j += 2) {
			if ((abs(i) == D[0]) && (j == -1))
				continue;
			//cerr << "j = " << j << "\n";
			//cerr << "Trying point " << X[0] + i << " " << (Y[0] + j*(D[0]-i)
			if (checkpoint(X[0] + i, Y[0] + j*(D[0]-abs(i)))) {
				nrofsol++;
				solx = X[0] + i;
				soly = Y[0] + j*(D[0]-abs(i));
				if (nrofsol == 2) {
					cout << "uncertain\n";
					return 0;
				}
			}
		}
	}
	if (nrofsol == 0)
		cout << "impossible\n";
	else
		cout << solx << " " << soly << "\n";
	return 0;
}
