/*
   Java solution for ManhattanPositioningSystem
   a problem for BAPC2016
   Solution written by Peter Kluit
   October 2016
*/

import java.util.*;

public class MPS_Simple_PGK{

    public static void main (String [] args){
      run();
    }
     private static void run() {
        Scanner scanner  = new Scanner(System.in);
        int beacons = scanner.nextInt();
        ManhattanSimple man = new ManhattanSimple(beacons);

        for (int b = 0; b < beacons; b++){
           int x = scanner.nextInt();
           int y = scanner.nextInt();
           int d = scanner.nextInt();
           man.add(x, y, d);
        }
        System.out.println(man.solution());
   }

}

class ManhattanSimple{

    int [][] beacon;
    int count = 0;
    String answer = null;

    ManhattanSimple(int size){
       beacon = new int [size][3];
    }

    public void add(int x, int y, int r){
       beacon[count][0] = x;
       beacon[count][1] = y;
       beacon[count][2] = r;
       count++;
    }

    public String solution(){

        int mx = beacon[0][0];
        int my = beacon[0][1];
        int r =  beacon[0][2];
        if (r == 0)
           check(mx, my);
        for (int dx = 0; dx < r; dx++){
           int dy = r - dx;
           check(mx + dx, my + dy);
           check(mx - dy, my + dx);
           check(mx + dy, my - dx);
           check(mx - dx, my - dy);
        }
        if (answer == null)
           return "impossible";
        else
           return answer;
    }

    private void check(int x, int y){
       for (int b = 1; b < beacon.length; b++){
          if (!contains(b, x, y))
             return;
       }
       update(x, y);
    }

    private boolean contains(int index, int x, int y){
       int [] b = beacon[index];
       return Math.abs(x - b[0]) + Math.abs(y- b[1]) == b[2];
    }

    private void update (int x, int y){
       if (answer == null)
          answer = x + " " + y;
       else
          answer = "uncertain";
    }

}
