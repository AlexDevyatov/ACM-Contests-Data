/*
 * Incorrect solution to Programming Tutors.
 *
 * This program repeatedly picks the student or tutor with the worst
 * second-best match, i.e. the person who stands to lose the most if
 * he does not get his preferred match.
 */

import java.io.*;
import java.util.*;

public class FailSemiGreedy
{

    // Semi-greedy matching.
    public static int match(int[][] distance)
    {
        int n = distance.length;

        // Remember whether student/tutor has already been matched.
        boolean[] student_matched = new boolean[n];
        boolean[] tutor_matched = new boolean[n];

        // Largest distance used so-far.
        int ans = 0;

        // Make N matches.
        for (int i = 0; i < n; i++) {

            int worst_dist    = -1;
            int worst_student = -1;
            int worst_tutor   = -1;

            // Find student with worst second-best tutor.
            for (int k = 0; k < n; k++) {
                if (!student_matched[k]) {
                    int best_tutor    = -1;
                    int best_dist     = Integer.MAX_VALUE;
                    int nextbest_dist = Integer.MAX_VALUE;
                    for (int t = 0; t < n; t++) {
                        if (!tutor_matched[t]) {
                            if (distance[k][t] <= best_dist) {
                                nextbest_dist = best_dist;
                                best_tutor    = t;
                                best_dist     = distance[k][t];
                            }
                        }
                    }
                    if (nextbest_dist > worst_dist) {
                        worst_dist    = nextbest_dist;
                        worst_student = k;
                        worst_tutor   = best_tutor;
                    }
                }
            }

            // Find tutor with worst second-best student.
            for (int k = 0; k < n; k++) {
                if (!tutor_matched[k]) {
                    int best_student  = -1;
                    int best_dist     = Integer.MAX_VALUE;
                    int nextbest_dist = Integer.MAX_VALUE;
                    for (int s = 0; s < n; s++) {
                        if (!student_matched[s]) {
                            if (distance[s][k] <= best_dist) {
                                nextbest_dist = best_dist;
                                best_student  = s;
                                best_dist     = distance[s][k];
                            }
                        }
                    }
                    if (nextbest_dist > worst_dist) {
                        worst_dist    = nextbest_dist;
                        worst_student = best_student;
                        worst_tutor   = k;
                    }
                }
            }

            assert (worst_student >= 0 && worst_tutor >= 0);

            if (distance[worst_student][worst_tutor] > ans) {
                ans = distance[worst_student][worst_tutor];
            }

            student_matched[worst_student] = true;
            tutor_matched[worst_tutor] = true;
        }

        return ans;
    }

    public static void main(String[] args)
    {
        try {
            BufferedReader ir = new BufferedReader(
                                  new InputStreamReader(System.in));

            // Read input.
            String s = ir.readLine();
            String[] w = s.split(" ");
            assert (w.length == 1);
            int n = Integer.parseInt(w[0]);
            assert (n >= 1 && n <= 100);

            int[][][] coords = new int[2][n][2];
            for (int t = 0; t <= 1; t++) {
                for (int i = 0; i < n; i++) {
                    s = ir.readLine();
                    w = s.split(" ");
                    assert (w.length == 2);
                    coords[t][i][0] = Integer.parseInt(w[0]);
                    coords[t][i][1] = Integer.parseInt(w[1]);
                    int lim = 100000000;
                    assert (coords[t][i][0] >= -lim && coords[t][i][0] <= lim);
                    assert (coords[t][i][1] >= -lim && coords[t][i][1] <= lim);
                }
            }

            // Calculate distance matrix.
            int[][] distance = new int[n][n];
            for (int i = 0; i < n; i++) {
                for (int k = 0; k < n; k++) {
                    int d = Math.abs(coords[0][i][0] - coords[1][k][0]) +
                            Math.abs(coords[0][i][1] - coords[1][k][1]);
                    distance[i][k] = d;
                }
            }

            // Find optimal matching.
            int ans = match(distance);

            // Write output.
            System.out.println(ans);

        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}

