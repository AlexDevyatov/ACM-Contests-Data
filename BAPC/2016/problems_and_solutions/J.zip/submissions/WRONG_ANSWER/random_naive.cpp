// WA to: Programming Tutors (random matching)
// By: Raymond van Bommel

#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cctype>
#include <climits>
#include <cassert>

#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <list>
#include <set>
#include <map>
#include <string>

#include <iostream>
#include <sstream>

#include <utility>
#include <functional>
#include <limits>
#include <numeric>
#include <algorithm> 

using namespace std;

int N, sol;
int stud[101][2], tutor[101][2];

int d(int i, int j) {
	return (abs(stud[i][0] - tutor[j][0]) + abs(stud[i][1] - tutor[j][1]));
}

void tryrandom() {
	int perm[101];
	int maxdist = 0;
	for (int i = 0; i < N; i++)
		perm[i] = -1;
	for (int i = 0; i < N; i++) {
		int r = rand() % (N-i);
		//cerr << "i =  " << i << " and r = " << r << "\n";
		int s = 0;
		while ((r > 0) || (perm[s] != -1)) {
			if (perm[s] == -1)
				r--;
			s++;
		}	
		perm[s] = i;
		maxdist = max(maxdist, d(s,i));
	}
	//cerr << "Tried permutation: ";
	//for (int i = 0; i < N; i++)
	//	cerr << i << "->" << perm[i] << " ";
	//cerr << "\n";
	sol = min(sol, maxdist);
}

int main () {
	cin >> N;
	for (int i = 0; i < N; i++)
		cin >> stud[i][0] >> stud[i][1];
	for (int i = 0; i < N; i++)
		cin >> tutor[i][0] >> tutor[i][1];
	sol = 2147483647;
	for (int i = 0; i < 100000; i++)
		tryrandom();
	cout << sol << "\n";
	return 0;
}
