// Try various linear projections from two-dimensional to one-dimensional space.
// The one-dimensional problem can be solved greedily.
// We choose the projection that yields the best result.
// 
// This algorithm is of course incorrect in general.

#include <iostream>
#include <vector>
#include <cassert>
#include <cmath>
#include <random>
#include <algorithm>

using namespace std;

const int MAX_N = 100;
const long long MAX_COORD = 100000000ll; // 10^8

const long long MY_INFINITY = 4 * MAX_COORD + 1;

const int NUM_RANDOM_ATTEMPTS = 123456;

const double MY_PI = 3.1415926535897932384626433832795;

struct point {
	long long x, y;
	double projection;
	bool operator<(const point& other) const {
		return projection < other.projection;
	}
	void project(double _x, double _y) {
		projection = _x * (double) x + _y * (double) y;
	}
	friend istream& operator>>(istream& is, point& p) {
		is >> p.x >> p.y;
		return is;
	}
};

long long dist(const point& p, const point& q) {
	return abs(p.x - q.x) + abs(p.y - q.y);
}

point students[MAX_N];
point tutors[MAX_N];

int main() {
	int N;
	cin >> N;
	for (int i = 0; i < N; i++) {
		cin >> students[i];
	}
	for (int i = 0; i < N; i++) {
		cin >> tutors[i];
	}
	vector<double> x(NUM_RANDOM_ATTEMPTS + 4);
	vector<double> y(NUM_RANDOM_ATTEMPTS + 4);
	x[0] = 0.0; y[0] = 1.0;
	x[1] = 1.0; y[1] = 0.0;
	x[2] = 1.0; y[2] = 1.0;
	x[3] = 1.0; y[2] = -1.0;
	default_random_engine generator;
	uniform_real_distribution<double> distr(-MY_PI, MY_PI);
	for (int i = 0; i < NUM_RANDOM_ATTEMPTS; i++) {
		double curAngle = distr(generator);
		x[i + 4] = cos(curAngle);
		y[i + 4] = sin(curAngle);
	}
	unsigned l = x.size();
	assert(l == y.size());
	long long best = MY_INFINITY;
	for (unsigned i = 0; i < l; i++) {
		for (int j = 0; j < N; j++) {
			students[j].project(x[i], y[i]);
			tutors[j].project(x[i], y[i]);
		}
		sort(students, students + N);
		sort(tutors, tutors + N);
		long long cur = 0;
		for (int j = 0; j < N; j++) {
			cur = max(cur, dist(students[j], tutors[j]));
		}
		best = min(best, cur);
	}
	assert(best >= 0 && best < MY_INFINITY);
	cout << best << endl;
	return 0;
}
