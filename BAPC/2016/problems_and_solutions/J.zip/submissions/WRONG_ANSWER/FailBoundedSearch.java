/*
 * Incorrect solution for Programming Tutors.
 *
 * This program starts with a semi-greedy matching.
 * It then performs a bounded search for local improvements
 * until no further improvements are found.
 *
 * This program is incorrect, i.e. there exist testcases on which
 * it gives a wrong answer.
 */

import java.io.*;
import java.util.*;

public class FailBoundedSearch
{

    // Semi-greedy matching.
    public static int[][] greedyMatch(int[][] distance)
    {
        int n = distance.length;

        // mate[0][i] = index of tutor to which student i is matched
        // mate[1][k] = index of student to which tutor k is matched,
        //              or -1 if tutor is unmatched.
        int mate[][] = new int[2][n];

        // Mark everyone as unmatched.
        for (int k = 0; k < n; k++) {
            mate[0][k] = -1;
            mate[1][k] = -1;
        }

        // Largest distance used so-far.
        int ans = 0;

        // Make N matches.
        for (int i = 0; i < n; i++) {

            int worst_dist    = -1;
            int worst_student = -1;
            int worst_tutor   = -1;

            // Find student with worst second-best tutor.
            for (int k = 0; k < n; k++) {
                if (mate[0][k] < 0) {
                    int best_tutor    = -1;
                    int best_dist     = Integer.MAX_VALUE;
                    int nextbest_dist = Integer.MAX_VALUE;
                    for (int t = 0; t < n; t++) {
                        if (mate[1][t] < 0) {
                            if (distance[k][t] <= best_dist) {
                                nextbest_dist = best_dist;
                                best_tutor    = t;
                                best_dist     = distance[k][t];
                            }
                        }
                    }
                    if (nextbest_dist > worst_dist) {
                        worst_dist    = nextbest_dist;
                        worst_student = k;
                        worst_tutor   = best_tutor;
                    }
                }
            }

            // Find tutor with worst second-best student.
            for (int k = 0; k < n; k++) {
                if (mate[1][k] < 0) {
                    int best_student  = -1;
                    int best_dist     = Integer.MAX_VALUE;
                    int nextbest_dist = Integer.MAX_VALUE;
                    for (int s = 0; s < n; s++) {
                        if (mate[0][s] < 0) {
                            if (distance[s][k] <= best_dist) {
                                nextbest_dist = best_dist;
                                best_student  = s;
                                best_dist     = distance[s][k];
                            }
                        }
                    }
                    if (nextbest_dist > worst_dist) {
                        worst_dist    = nextbest_dist;
                        worst_student = best_student;
                        worst_tutor   = k;
                    }
                }
            }

            assert (worst_student >= 0 && worst_tutor >= 0);

            if (distance[worst_student][worst_tutor] > ans) {
                ans = distance[worst_student][worst_tutor];
            }

            mate[0][worst_student] = worst_tutor;
            mate[1][worst_tutor]   = worst_student;
        }

        return mate;
    }


    // Brute-force search for an augmenting path of length up to maxdepth.
    public static boolean improve(int[][] distance, int[][] mate,
                                  boolean[] used_student,
                                  int first_student, int cur_student,
                                  int max_dist, int max_depth)
    {
        int n = distance.length;

        int first_tutor = mate[0][first_student];
        int cur_tutor   = mate[0][cur_student];

        // Try to close the cycle.
        if (distance[cur_student][first_tutor] < max_dist) {
            mate[0][cur_student] = first_tutor;
            mate[1][first_tutor] = cur_student;
            return true;
        }

        // Stop at max search depth.
        if (max_depth == 0) {
            return false;
        }

        // Search for new intermediate student.
        for (int s = 0; s < n; s++) {
            if (!used_student[s]) {
                int t = mate[0][s];
                if (distance[cur_student][t] < max_dist) {
                    used_student[s] = true;
                    boolean ok = improve(distance, mate, used_student,
                                         first_student, s,
                                         max_dist, max_depth - 1);
                    used_student[s] = false;
                    if (ok) {
                        mate[0][cur_student] = t;
                        mate[1][t] = cur_student;
                        return true;
                    }
                }
            }
        }

        // Failed.
        return false;
    }


    // Bounded search for matching with lowest maximum distance.
    public static int match(int[][] distance)
    {
        int n = distance.length;

        // mate[0][i] = index of tutor to which student i is matched
        // mate[1][k] = index of student to which tutor k is matched,
        //              or -1 if tutor is unmatched.
        int mate[][] = greedyMatch(distance);

        // Scratch space for recursive search.
        boolean[] used_student = new boolean[n];

        int ans;

        while (true) {

            // Find largest distance in current matching.
            ans = 0;
            int worst_student = -1;
            int worst_tutor = -1;

            for (int i = 0; i < n; i++) {
                int d = distance[i][mate[0][i]];
                if (d > ans) {
                    ans = d;
                    worst_student = i;
                    worst_tutor = mate[0][i];
                }
            }

            for (int k = 0; k < n; k++) {
                int d = distance[mate[1][k]][k];
                if (d > ans) {
                    ans = d;
                    worst_student = mate[1][k];
                    worst_tutor = k;
                }
            }

            if (ans == 0) {
                break;
            }

            used_student[worst_student] = true;

            // Search up to depth 2.
            boolean ok = improve(distance, mate, used_student,
                                 worst_student, worst_student,
                                 ans, 2);

            // Search up to depth 4.
            if (!ok) {
                ok = improve(distance, mate, used_student,
                             worst_student, worst_student,
                             ans, 4);
            }

            used_student[worst_student] = false;

            if (!ok) {
                break;
            }
        }

        return ans;
    }


    public static void main(String[] args)
    {
        try {
            BufferedReader ir = new BufferedReader(
                                  new InputStreamReader(System.in));

            // Read input.
            String s = ir.readLine();
            String[] w = s.split(" ");
            assert (w.length == 1);
            int n = Integer.parseInt(w[0]);
            assert (n >= 1 && n <= 100);

            int[][][] coords = new int[2][n][2];
            for (int t = 0; t <= 1; t++) {
                for (int i = 0; i < n; i++) {
                    s = ir.readLine();
                    w = s.split(" ");
                    assert (w.length == 2);
                    coords[t][i][0] = Integer.parseInt(w[0]);
                    coords[t][i][1] = Integer.parseInt(w[1]);
                    int lim = 100000000;
                    assert (coords[t][i][0] >= -lim && coords[t][i][0] <= lim);
                    assert (coords[t][i][1] >= -lim && coords[t][i][1] <= lim);
                }
            }

            // Calculate distance matrix.
            int[][] distance = new int[n][n];
            for (int i = 0; i < n; i++) {
                for (int k = 0; k < n; k++) {
                    int d = Math.abs(coords[0][i][0] - coords[1][k][0]) +
                            Math.abs(coords[0][i][1] - coords[1][k][1]);
                    distance[i][k] = d;
                }
            }

            // Find optimal matching.
            int ans = match(distance);

            // Write output.
            System.out.println(ans);

        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

}
