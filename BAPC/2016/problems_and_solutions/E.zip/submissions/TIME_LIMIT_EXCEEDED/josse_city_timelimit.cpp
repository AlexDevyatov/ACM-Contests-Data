// This is a solution that gives the right answer (hopefully), but takes too
// much time. It uses Dijkstra's algorithm, but the graph is stored as a matrix.
// Therefore each call to Dijkstra's algorithm takes O(n^2) time: too slow!
//
// WARNING: this solution will use 800MB of memory, even for small test cases!

#include <iostream>
#include <cassert>

using namespace std;

const int MIN_N = 2;
const int MAX_N = 10000;
const int MIN_M = 1;
const int MAX_M = 100000;
const int MIN_X = 0;
const int MAX_X = 10000;
const long long MIN_T = 1;
const long long MAX_T = 1000000000;

const long long IMPOSSIBLE = 10000000000000000ll;

int n, m, x;
long long c[MAX_N][MAX_N]; // <-- large hard-coded array (800MB)
long long d[MAX_N];
bool processed[MAX_N];

// Find the shortest path from s to t, using only edges of length at most max_t.
long long dijkstra(int s, int t, long long max_t) {
	// Initialise arrays:
	for (int i = 0; i < n; i++) {
		d[i] = IMPOSSIBLE;
		processed[i] = false;
	}
	d[s] = 0;
	
	// Dijkstra's algorithm:
	while (true) {
		// Find a vertex to process:
		int curVertex = -1;
		for (int i = 0; i < n; i++) {
			if (processed[i]) continue;
			if (curVertex == -1 || d[i] < d[curVertex]) {
				curVertex = i;
			}
		}
		if (curVertex == -1 || d[curVertex] == IMPOSSIBLE) return IMPOSSIBLE;
		if (curVertex == t) return d[t];
		// Process current vertex:
		for (int nextVertex = 0; nextVertex < n; nextVertex++) {
			if (c[curVertex][nextVertex] <= max_t) {
				d[nextVertex] = min(d[nextVertex], d[curVertex] + c[curVertex][nextVertex]);
			}
		}
		processed[curVertex] = true;
	}
}

int main() {
	// Read first line of input:
	cin >> n >> m >> x;
	assert(n >= MIN_N && n <= MAX_N);
	assert(m >= MIN_M && m <= MAX_M);
	assert(x >= MIN_X && x <= MAX_X);
	
	// Initialise distance matrix:
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			c[i][j] = (i == j ? 0 : IMPOSSIBLE);
		}
	}
	
	// Read graph:
	for (int i = 0; i < m; i++) {
		int a, b;
		long long t;
		cin >> a >> b >> t;
		a--; b--;
		assert(a >= 0 && a < n);
		assert(b >= 0 && b < n);
		assert(t >= MIN_T && t <= MAX_T);
		c[a][b] = min(c[a][b], t);
		c[b][a] = min(c[b][a], t);
	}
	
	// Calculate normal distance, taking the shortest route in a regular car:
	long long normalDistance = dijkstra(0, n - 1, MAX_T);
	assert(normalDistance < IMPOSSIBLE);
	long long maxDistance = (normalDistance * (100ll + x)) / 100ll;
	
	// Binary search:
	long long lo = MIN_T - 1;
	long long hi = MAX_T + 1;
	while (hi - lo > 1) {
		long long mid = (lo + hi) / 2;
		(dijkstra(0, n - 1, mid) > maxDistance ? lo : hi) = mid;
	}
	
	// Output answer:
	cout << hi << endl;
	return 0;
}
