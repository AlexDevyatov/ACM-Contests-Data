/**
 * Dijkstra variant
 */


import java.util.*;
import java.io.*;

/**
 * @author mathijs
 * Charles
 * with variant of Dijkstra, but with two labels
 */
public class Solution {
	TreeMap<Integer,Node> nodes;
	static int maxid = 0;
	static long maxd = 0;
	
	public static void main(String[] args) {
	          Scanner sc = new Scanner(System.in);
        	  Solution sol = new Solution();
        	  int n = sc.nextInt();
        	  int m = sc.nextInt();
        	  int x = sc.nextInt();
        	  sol.maxid = n-1;
        	  for( int i = 1; i <= m; ++i )
        	  {
        		  int from = sc.nextInt();
        		  int to = sc.nextInt();
        		  int c = sc.nextInt();
				  from--; to--;
        		  sol.addEdge( i, from, to, c );
        	  }
	          sc.close();
        	  long d = sol.getLength();
        	  sol.maxd = (100*d+x*d)/100;
//        	  System.out.println("maxd: " + sol.maxd);
        	  for( Node node : sol.nodes.values() )
        		  node.visited = new TreeMap<Long,Long>();
        	  sol.solveDijkstra();
	}

	public Solution(){
		nodes = new TreeMap<Integer,Node>();
	}
	
	public void solveDijkstra()
	{
		PriorityQueue<State> Q = new PriorityQueue<State>();
		// contains width of bottleneck, and position
		State s = new State( 0, 0, 0);
		Q.add(s);
		while(! Q.isEmpty())
		{
			s = Q.remove();
			if( s.id == maxid )
				break;
			Node n = nodes.get(s.id);
			if( ! n.isVisited(s.d, s.width) )
			{
				n.addVisited(s.d, s.width);
				int cap = 0;
				int pto = 0;
				for( Edge e : n.neighbors ){
					Node to = e.to;
					if( to.id == s.id )
						to = e.from;
					long d = s.d+e.cap;
							long w = Math.max(s.width, e.cap); 
							if( d <= maxd && ! to.isVisited(d, w) )
							{
								State nb = new State( to.id , w, d );
								Q.add(nb);
//								System.out.println("added: " + nb.id + " w:"  + nb.width + " d:" + nb.d);
							}
				}
			}
		}
  	  System.out.println( s.width );
	}

	public long getLength()
	{
		TreeMap<Long,Long> visited = new TreeMap<Long,Long>();
		PriorityQueue<NState> Q = new PriorityQueue<NState>();
		NState s = new NState( 0, 0);
		Q.add(s);
		while(! Q.isEmpty())
		{
			s = Q.remove();
//			System.out.println("popped: " + s.id + " d:" + s.d);
			if( s.id == maxid )
				return s.d;
			Node n = nodes.get(s.id);
			if( n.visited == null)
			{
				n.visited = visited;
				for( Edge e : n.neighbors ){
					Node to = e.to;
					if( to.id == s.id )
						to = e.from;
					if( to.visited == null )
					{
								long d = s.d+e.cap;
								NState nb = new NState( to.id , d );
								Q.add(nb);
//								System.out.println("added: " + nb.id + " d:" + nb.d);
					}
				}
			}
		}
		return -1;
	}

	public void addEdge(int id, int from, int to, long cap )
	{		
		Node f = nodes.get( from );
		if( f == null )
		{
			f = new Node( from );
			nodes.put( from, f );
		}
		Node t = nodes.get( to );
		if( t == null )
		{
			t = new Node( to );
			nodes.put( to, t );
		}
		Edge e = new Edge( id, f, t, cap );
		t.addNeighbor(e);
		f.addNeighbor(e);

	}
		
	protected class Node {
		ArrayList<Edge> neighbors;
		int id;
		TreeMap<Long,Long> visited;
		
		public Node( int id )
		{
			this.id = id;
			neighbors = new ArrayList<Edge>();
			visited = null;
		}
		
		public void addNeighbor( Edge e )
		{
			neighbors.add(e);
		}
		
		/** add if not dominated by existing ones **/
		public void addVisited( long d, long cap )
		{
			if( ! isVisited( d, cap ) )
			{
				visited.put(cap,d);
				for( Map.Entry<Long,Long> e : visited.tailMap(cap,false).entrySet() )
					if( e.getValue() >= d )
						visited.remove(e.getKey());
				// remove larger cap and larger distance
			}
		}
		
		public boolean isVisited( long d, long cap )
		{
			Long mindistance = visited.get(cap);
			if( mindistance != null )
				return ( mindistance <= d );
			else
			{
				// is there one with smaller cap and less distance?
				// note: invariant: if cap smaller, then distance not
				Map.Entry<Long,Long> previous = visited.lowerEntry(cap);
				return( previous != null && previous.getValue() <= d );
			}
		}
	}
	
//	protected class Edge implements Comparable<Edge> {
	protected class Edge  {
		Node from;
		Node to;
		long cap;
		int id;
		
		public Edge( int id, Node from, Node to, long cap )
		{
			this.id = id;
			this.from = from;
			this.to = to;
			this.cap = cap;
		}
		
//		@Override
//		public int compareTo( Edge other )
//		{
//			return other.to.id - this.to.id;
//		}
	
		
	}
	
	protected class State implements Comparable<State> {
		long width;
		int id;
		long d;
	
		public State( int id, long width, long d )
		{
			this.id = id;
			this.width = width;
			this.d = d;
		}
		
		@Override
		public int compareTo( State other )
		{
			long diff = this.width - other.width;
					if( diff < 0 )
						return -1;
					if(diff > 0)
						return 1;
					if( diff == 0 )
					{
						return (int) (this.d - other.d);
					}
					return 0;
		}
	
	}	
	protected class NState implements Comparable<NState> {
		int id;
		long d;
	
		public NState( int id, long d )
		{
			this.id = id;
			this.d = d;
		}
		
		@Override
		public int compareTo( NState other )
		{
			long diff = this.d - other.d;
			if( diff < 0 )
				return -1;
			if(diff > 0)
				return 1;
			return 0;		
		}
	
	}	
}
