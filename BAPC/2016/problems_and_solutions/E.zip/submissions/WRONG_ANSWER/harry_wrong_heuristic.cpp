#include <iostream> // strings/streams
#include <cstdio> // utils
#include <string>
#include <cstring>
#include <sstream>
#include <vector> // datastructures
#include <list>
#include <set>
#include <map>
#include <unordered_map>
#include <queue>
#include <stack>
#include <bitset>
#include <tuple> // quick compare
#include <numeric>
#include <iterator>
#include <algorithm>
#include <cmath>
#include <chrono>
#include <cassert>
#include <complex>

#define REP(i,n)	for(auto i = decltype(n)(0); i<(n); i++)
#define all(v)		begin(v), end(v)

using namespace std;
using ll  = long long;
using ull = unsigned long long;
using ld  = long double;
using ii  = pair<ll,ll>;
using vi  = vector<ll>;
using vii = vector<ii>;
using vb  = vector<bool>;
using vvi = vector<vi>;
using vvii = vector<vii>;

constexpr int  INF = 1e9+1; // < 1e9 - -1e9
constexpr ll LLINF = 1e18+1;

struct Edge{ int v; ll weight; };	// input edges
struct PQ{ ll d; int v; };			// distance and target
bool operator>(const PQ &l, const PQ &r){ return l.d > r.d; }

ll dijkstra(vector<vector<Edge>> &edges, int s, int t) {
	vector<ll> dist(edges.size(),LLINF);
	priority_queue<PQ,vector<PQ>,greater<PQ>> pq;
	dist[s] = 0; pq.push({0, s});
	while (!pq.empty()) {
		auto d = pq.top().d; auto u = pq.top().v; pq.pop();
		if(u==t) break;			// target reached
		if (d == dist[u])
			for(auto &e : edges[u]) if (dist[e.v] > d + e.weight)
				pq.push({dist[e.v] = d + e.weight, e.v});
	}
	return dist[t];
}

struct PQ_bat{ ll battery; ll d; int v; };			// max battery used, distance and target
bool operator>(const PQ_bat &l, const PQ_bat &r){ return l.battery > r.battery; }

ll dijkstra_bat(vector<vector<Edge>> &edges, int s, int t, ll max_dist) {
	ll latest_bat_size = 0;
	vector<ll> dist(edges.size(),LLINF);
	vector<ll> bat_size(edges.size(),LLINF);
	priority_queue<PQ_bat,vector<PQ_bat>,greater<PQ_bat>> pq_bat;
	dist[s] = 0; bat_size[s] = 0;
	pq_bat.push({0, 0, s});
	while (!pq_bat.empty()) {
		auto battery = pq_bat.top().battery; auto d = pq_bat.top().d; auto u = pq_bat.top().v; pq_bat.pop();
		if(u==t) { latest_bat_size = bat_size[t]; break; }			// target reached
		if (battery == bat_size[u])
			for(auto &e : edges[u]) if (d + e.weight <= max_dist && bat_size[e.v] > max(battery, e.weight))
			{
				pq_bat.push({bat_size[e.v] = max(battery, e.weight), dist[e.v] = d + e.weight, e.v});
				latest_bat_size = bat_size[e.v];
			}
	}
	return latest_bat_size;
}


int main()
{
	// This solution tries to minimize the battery used, and just stops when the maximum allowed distance is reached.
	// EXPECTED RESULT: WRONG_ANSWER
	int n, m, x;
	cin >> n >> m >> x; 
	vector<vector<Edge>> edges(n);
	for(int i = 0; i < m; ++i) // Adding all edges. 
	{
		int c1, c2;
		ll t;
		cin >> c1 >> c2 >> t;
		c1--; c2--;
		Edge e1 = {c2, t};
		edges[c1].push_back(e1);
		Edge e2 = {c1, t}; // Both ways. 
		edges[c2].push_back(e2);
	}
	ll fastest = dijkstra(edges, 0, n-1);
	assert(fastest < LLINF);
	ll max_allowed = (fastest * (100 + x))/100;
	
	ll ans = dijkstra_bat(edges, 0, n-1, max_allowed);
	
	cout << ans << "\n"; 
}