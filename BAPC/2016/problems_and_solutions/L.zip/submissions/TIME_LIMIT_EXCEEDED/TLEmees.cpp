#include <iostream>
#include <algorithm>

using namespace std;

int main() {
  int n;
  cin >> n;
  vector<unsigned long long> stick(n);

  for(int i = 0; i < n; i++)
    cin >> stick[i];

  bool maketriangle = false;
  unsigned long long a,b,c,tmp;
  for(int i = 0; i < n; i++) {
    for(int j = i+1; j < n; j++) {
      for(int k = j + 1; k < n; k++) {
        a = stick[i];
        b = stick[j];
        c = stick[k];

        if(a < b) {
          tmp = a;
          a = b;
          b = tmp;
        }
        if(a < c) {
          tmp = a;
          a = c;
          c = tmp;
        }

        if(a < b + c) {
          //cout << "possible with " << a << " " << b << " " << c << endl;
          maketriangle = true;
          break;
        }
      }
      if(maketriangle)
        break;
    }
    if(maketriangle)
      break;
  }

  if(maketriangle)
    cout << "possible" << endl;
  else
    cout << "impossible" << endl;
  return 0;
}
